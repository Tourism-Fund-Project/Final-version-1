﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Tourism_Fund_Distribution_final.Forms;

namespace Tourism_Fund_Distribution_final
{
    public partial class AddReviews : Form
    {
        private Reviews mainForm;
        public AddReviews(Reviews form)
        {
            InitializeComponent();
            mainForm = form;
        }

        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";


        private void AddReview()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddReviews", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                // Adding parameters corresponding to the stored procedure
                cmd.Parameters.AddWithValue("@PerformanceRank", int.Parse(txt_PerformanceRank.Text));
                cmd.Parameters.AddWithValue("@Date", dateTimePickerReviewDate.Value);
                cmd.Parameters.AddWithValue("@NumberOfTourists", int.Parse(txt_NumTourists.Text));
                cmd.Parameters.AddWithValue("@DevelopmentName", cbxDevelopmentName.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@AttractionName", txt_AttractionName.Text.Trim());
                cmd.Parameters.AddWithValue("@AttractionSupervisorFullName", cbxSupervisorFullName.SelectedItem.ToString());
                //cmd.Parameters.AddWithValue("@RegionID", int.Parse(txt_RegionID.Text)); // Assuming txt_RegionID is a TextBox where the Region ID is entered

                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Tourist attraction Review added successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private void btn_SubmitReview_Click(object sender, EventArgs e)
        {
            AddReview();
            mainForm.ReloadReviewsDataGrid();
            this.Close();

        }
        private void LoadSupervisorNames()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT First_Name, Last_Name FROM dbo.Attraction_Supervisor", connection);
                try
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string fullName = reader["First_Name"].ToString() + " " + reader["Last_Name"].ToString();
                        cbxSupervisorFullName.Items.Add(fullName);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading supervisor names: " + ex.Message);
                }
            }
        }

        private void LoadDevelopmentNames()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT Name FROM dbo.Attraction_Development", connection);
                try
                {
                    connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cbxDevelopmentName.Items.Add(reader["Name"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading development names: " + ex.Message);
                }
            }
        }


        private void AddReviews_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            LoadDevelopmentNames();
            LoadSupervisorNames();
        }
        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }
    }
}
