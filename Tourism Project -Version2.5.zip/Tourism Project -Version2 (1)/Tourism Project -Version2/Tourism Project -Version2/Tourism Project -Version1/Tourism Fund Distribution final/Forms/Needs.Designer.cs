﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Needs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAttractionSupervisorLName = new System.Windows.Forms.TextBox();
            this.txtAccessFundsID = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAttractionSupervisorFName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnDel = new System.Windows.Forms.Button();
            this.cbxCategoryNeeds = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtDescr = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewNeeds = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_Filter_Needs = new System.Windows.Forms.Button();
            this.cbx_FilterNeeds = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txt_FilterName = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNeeds)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtAttractionSupervisorLName);
            this.groupBox1.Controls.Add(this.txtAccessFundsID);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtAttractionSupervisorFName);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btnDel);
            this.groupBox1.Controls.Add(this.cbxCategoryNeeds);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnUpdate);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.txtDescr);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(51, 560);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(729, 303);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tourist Attraction Repair info";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(380, 142);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 40);
            this.label7.TabIndex = 33;
            this.label7.Text = "Attraction Supervisor \nSurname:";
            // 
            // txtAttractionSupervisorLName
            // 
            this.txtAttractionSupervisorLName.Location = new System.Drawing.Point(548, 145);
            this.txtAttractionSupervisorLName.Name = "txtAttractionSupervisorLName";
            this.txtAttractionSupervisorLName.Size = new System.Drawing.Size(170, 26);
            this.txtAttractionSupervisorLName.TabIndex = 32;
            // 
            // txtAccessFundsID
            // 
            this.txtAccessFundsID.Location = new System.Drawing.Point(548, 92);
            this.txtAccessFundsID.Name = "txtAccessFundsID";
            this.txtAccessFundsID.Size = new System.Drawing.Size(170, 26);
            this.txtAccessFundsID.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(381, 97);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 20);
            this.label10.TabIndex = 28;
            this.label10.Text = "Repairs Fee:";
            // 
            // txtAttractionSupervisorFName
            // 
            this.txtAttractionSupervisorFName.Location = new System.Drawing.Point(170, 142);
            this.txtAttractionSupervisorFName.Name = "txtAttractionSupervisorFName";
            this.txtAttractionSupervisorFName.Size = new System.Drawing.Size(148, 26);
            this.txtAttractionSupervisorFName.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(161, 40);
            this.label9.TabIndex = 26;
            this.label9.Text = "Attraction Supervisor \nName:";
            // 
            // btnDel
            // 
            this.btnDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDel.Location = new System.Drawing.Point(502, 238);
            this.btnDel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(218, 42);
            this.btnDel.TabIndex = 25;
            this.btnDel.Text = "Delete";
            this.toolTip3.SetToolTip(this.btnDel, "Deletes Existing Tourist Attraction Needs");
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // cbxCategoryNeeds
            // 
            this.cbxCategoryNeeds.FormattingEnabled = true;
            this.cbxCategoryNeeds.Location = new System.Drawing.Point(548, 49);
            this.cbxCategoryNeeds.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbxCategoryNeeds.Name = "cbxCategoryNeeds";
            this.cbxCategoryNeeds.Size = new System.Drawing.Size(170, 28);
            this.cbxCategoryNeeds.TabIndex = 8;
            this.cbxCategoryNeeds.SelectedIndexChanged += new System.EventHandler(this.cbxCategoryNeeds_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(381, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Category of Needs:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(256, 238);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(218, 42);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Update";
            this.toolTip2.SetToolTip(this.btnUpdate, "Updates Existing Tourist Attraction Needs");
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(14, 238);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(218, 42);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.toolTip2.SetToolTip(this.btnAdd, "Adds New Tourist Attraction Needs");
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtDescr
            // 
            this.txtDescr.Location = new System.Drawing.Point(134, 88);
            this.txtDescr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDescr.Name = "txtDescr";
            this.txtDescr.Size = new System.Drawing.Size(148, 26);
            this.txtDescr.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 92);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(134, 46);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(148, 26);
            this.txtName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 51);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name:";
            // 
            // dataGridViewNeeds
            // 
            this.dataGridViewNeeds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNeeds.Location = new System.Drawing.Point(51, 309);
            this.dataGridViewNeeds.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewNeeds.Name = "dataGridViewNeeds";
            this.dataGridViewNeeds.RowHeadersWidth = 62;
            this.dataGridViewNeeds.Size = new System.Drawing.Size(729, 208);
            this.dataGridViewNeeds.TabIndex = 14;
            this.dataGridViewNeeds.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNeeds_CellContentClick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txt_FilterName);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.btn_reset);
            this.groupBox3.Controls.Add(this.btn_Filter_Needs);
            this.groupBox3.Controls.Add(this.cbx_FilterNeeds);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(51, 55);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(404, 228);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Tourist Attractions by";
            // 
            // btn_reset
            // 
            this.btn_reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reset.Location = new System.Drawing.Point(15, 172);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(182, 42);
            this.btn_reset.TabIndex = 26;
            this.btn_reset.Text = "Refresh";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_Filter_Needs
            // 
            this.btn_Filter_Needs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_Needs.Location = new System.Drawing.Point(206, 172);
            this.btn_Filter_Needs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Filter_Needs.Name = "btn_Filter_Needs";
            this.btn_Filter_Needs.Size = new System.Drawing.Size(182, 42);
            this.btn_Filter_Needs.TabIndex = 25;
            this.btn_Filter_Needs.Text = "Filter";
            this.toolTip1.SetToolTip(this.btn_Filter_Needs, "Displays Needs According to Inputs provided");
            this.btn_Filter_Needs.UseVisualStyleBackColor = true;
            this.btn_Filter_Needs.Click += new System.EventHandler(this.btn_Filter_Needs_Click);
            // 
            // cbx_FilterNeeds
            // 
            this.cbx_FilterNeeds.FormattingEnabled = true;
            this.cbx_FilterNeeds.Location = new System.Drawing.Point(208, 85);
            this.cbx_FilterNeeds.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbx_FilterNeeds.Name = "cbx_FilterNeeds";
            this.cbx_FilterNeeds.Size = new System.Drawing.Size(180, 28);
            this.cbx_FilterNeeds.TabIndex = 24;
            this.cbx_FilterNeeds.SelectedIndexChanged += new System.EventHandler(this.cbx_FilterNeeds_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 85);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Category of Need";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(558, 285);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(216, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Select Row to Update/Delete";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Click";
            // 
            // toolTip2
            // 
            this.toolTip2.IsBalloon = true;
            this.toolTip2.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip2.ToolTipTitle = "Click";
            // 
            // toolTip3
            // 
            this.toolTip3.IsBalloon = true;
            this.toolTip3.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip3.ToolTipTitle = "Click";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 27;
            this.label1.Text = "Name of Repair";
            // 
            // txt_FilterName
            // 
            this.txt_FilterName.Location = new System.Drawing.Point(206, 38);
            this.txt_FilterName.Name = "txt_FilterName";
            this.txt_FilterName.Size = new System.Drawing.Size(182, 26);
            this.txt_FilterName.TabIndex = 28;
            // 
            // Needs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 915);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewNeeds);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Needs";
            this.Text = "Needs";
            this.Load += new System.EventHandler(this.Needs_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNeeds)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbxCategoryNeeds;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtDescr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewNeeds;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbx_FilterNeeds;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btn_Filter_Needs;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox txtAccessFundsID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAttractionSupervisorFName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAttractionSupervisorLName;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_FilterName;
        private System.Windows.Forms.Label label1;
    }
}