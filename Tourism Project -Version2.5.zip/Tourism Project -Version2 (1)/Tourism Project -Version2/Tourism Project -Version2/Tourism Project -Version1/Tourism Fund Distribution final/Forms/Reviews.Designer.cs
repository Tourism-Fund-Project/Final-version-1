﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Reviews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewReviews = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cbxRegions1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewTA = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1Reviews = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_Filter_PerformanceRank = new System.Windows.Forms.TextBox();
            this.btn_Filter_Reviews = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NumTourists = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReviews)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTA)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panel1Reviews.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewReviews);
            this.groupBox1.Location = new System.Drawing.Point(50, 668);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(1054, 272);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reviews";
            // 
            // dataGridViewReviews
            // 
            this.dataGridViewReviews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReviews.Location = new System.Drawing.Point(9, 34);
            this.dataGridViewReviews.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewReviews.Name = "dataGridViewReviews";
            this.dataGridViewReviews.RowHeadersWidth = 62;
            this.dataGridViewReviews.Size = new System.Drawing.Size(1036, 229);
            this.dataGridViewReviews.TabIndex = 21;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(878, 386);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(218, 42);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add Reviews";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cbxRegions1
            // 
            this.cbxRegions1.FormattingEnabled = true;
            this.cbxRegions1.Location = new System.Drawing.Point(615, 40);
            this.cbxRegions1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbxRegions1.Name = "cbxRegions1";
            this.cbxRegions1.Size = new System.Drawing.Size(180, 28);
            this.cbxRegions1.TabIndex = 18;
            this.cbxRegions1.SelectedIndexChanged += new System.EventHandler(this.cbxRegions1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(672, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Province";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewTA);
            this.groupBox2.Location = new System.Drawing.Point(50, 88);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(1046, 289);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tourist Attractions";
            // 
            // dataGridViewTA
            // 
            this.dataGridViewTA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTA.Location = new System.Drawing.Point(26, 29);
            this.dataGridViewTA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewTA.Name = "dataGridViewTA";
            this.dataGridViewTA.RowHeadersWidth = 62;
            this.dataGridViewTA.Size = new System.Drawing.Size(1011, 235);
            this.dataGridViewTA.TabIndex = 21;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel1Reviews);
            this.groupBox3.Location = new System.Drawing.Point(50, 405);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(497, 252);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Tourist Attractions Reviews by";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // panel1Reviews
            // 
            this.panel1Reviews.Controls.Add(this.button2);
            this.panel1Reviews.Controls.Add(this.txt_Filter_PerformanceRank);
            this.panel1Reviews.Controls.Add(this.btn_Filter_Reviews);
            this.panel1Reviews.Controls.Add(this.label2);
            this.panel1Reviews.Controls.Add(this.label3);
            this.panel1Reviews.Controls.Add(this.txt_NumTourists);
            this.panel1Reviews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1Reviews.Location = new System.Drawing.Point(4, 24);
            this.panel1Reviews.Name = "panel1Reviews";
            this.panel1Reviews.Size = new System.Drawing.Size(489, 223);
            this.panel1Reviews.TabIndex = 23;
            this.panel1Reviews.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(18, 176);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(218, 42);
            this.button2.TabIndex = 26;
            this.button2.Text = "Refesh";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_Filter_PerformanceRank
            // 
            this.txt_Filter_PerformanceRank.Location = new System.Drawing.Point(269, 38);
            this.txt_Filter_PerformanceRank.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Filter_PerformanceRank.Name = "txt_Filter_PerformanceRank";
            this.txt_Filter_PerformanceRank.Size = new System.Drawing.Size(216, 26);
            this.txt_Filter_PerformanceRank.TabIndex = 25;
            // 
            // btn_Filter_Reviews
            // 
            this.btn_Filter_Reviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_Reviews.Location = new System.Drawing.Point(267, 176);
            this.btn_Filter_Reviews.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Filter_Reviews.Name = "btn_Filter_Reviews";
            this.btn_Filter_Reviews.Size = new System.Drawing.Size(218, 42);
            this.btn_Filter_Reviews.TabIndex = 23;
            this.btn_Filter_Reviews.Text = "Filter";
            this.btn_Filter_Reviews.UseVisualStyleBackColor = true;
            this.btn_Filter_Reviews.Click += new System.EventHandler(this.btn_Filter_Reviews_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Performance rank:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 85);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Number of tourists:";
            // 
            // txt_NumTourists
            // 
            this.txt_NumTourists.Location = new System.Drawing.Point(269, 85);
            this.txt_NumTourists.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_NumTourists.Name = "txt_NumTourists";
            this.txt_NumTourists.Size = new System.Drawing.Size(216, 26);
            this.txt_NumTourists.TabIndex = 3;
            this.txt_NumTourists.TextChanged += new System.EventHandler(this.txt_NumTourists_TextChanged);
            // 
            // Reviews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 949);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbxRegions1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Reviews";
            this.Text = "Reviews";
            this.Load += new System.EventHandler(this.Reviews_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReviews)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTA)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.panel1Reviews.ResumeLayout(false);
            this.panel1Reviews.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox cbxRegions1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewReviews;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewTA;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_NumTourists;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Filter_Reviews;
        private System.Windows.Forms.Panel panel1Reviews;
        private System.Windows.Forms.TextBox txt_Filter_PerformanceRank;
        private System.Windows.Forms.Button button2;
    }
}