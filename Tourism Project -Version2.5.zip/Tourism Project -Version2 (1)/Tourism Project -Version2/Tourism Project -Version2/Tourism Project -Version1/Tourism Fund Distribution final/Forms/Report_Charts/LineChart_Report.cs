﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms.Report_Charts
{
    public partial class LineChart_Report : Form
    {
        public LineChart_Report()
        {
            InitializeComponent();

        }
       

        private void LineChart_Report_Load(object sender, EventArgs e)
        {
            string query = @"
    SELECT 
        ta.Name AS [Attraction Name], 
        rev.Number_of_Tourists, 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    ORDER BY 
        rev.Performance_Rank DESC
    OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY;

    SELECT 
        ta.Name AS [Attraction Name], 
        rev.Number_of_Tourists, 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    ORDER BY 
        rev.Performance_Rank ASC
    OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY;
    ";
            using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
            {
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                //MessageBox.Show("Data Retrieved!"); // Debugging step

                if (ds.Tables[0].Rows.Count > 0)
                {
                    cartesianChart1.Series.Clear();

                    var touristsSeries = new LineSeries
                    {
                        Title = "Number of Tourists",
                        Values = new ChartValues<int>()
                    };

                    var rankSeries = new LineSeries
                    {
                        Title = "Performance Rank",
                        Values = new ChartValues<int>()
                    };

                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        touristsSeries.Values.Add(Convert.ToInt32(row["Number_of_Tourists"]));
                        rankSeries.Values.Add(Convert.ToInt32(row["Performance_Rank"]));
                    }

                    cartesianChart1.Series.Add(touristsSeries);
                    cartesianChart1.Series.Add(rankSeries);

                    cartesianChart1.AxisX.Add(new Axis
                    {
                        Title = "Attraction Name",
                        Labels = ds.Tables[0].AsEnumerable().Select(x => x["Attraction Name"].ToString()).ToArray()
                    });

                    cartesianChart1.AxisY.Add(new Axis
                    {
                        Title = "Values",
                        LabelFormatter = value => value.ToString()
                    });

                    cartesianChart1.Visibility = System.Windows.Visibility.Visible;
                    MessageBox.Show("Data Retrived and Chart Updated!"); // Debugging step
                }
                else
                {
                    MessageBox.Show("No data found for the query."); // Debugging step
                }
            }
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
