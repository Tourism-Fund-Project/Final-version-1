﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Data.SqlClient;
using System.Net.NetworkInformation;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class PieChart_Report : Form
    {
        public PieChart_Report()
        {
            InitializeComponent();

        }

        private void PieChart_Report_Load(object sender, EventArgs e)
        {
            string query = @"
SELECT 
    r.Name AS [Region Name], 
    SUM(rev.Number_of_Tourists) AS [Total Tourists]
FROM 
    TouristAttraction ta
JOIN 
    Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
JOIN 
    Regions r ON ta.Region_ID = r.Region_ID
GROUP BY 
    r.Name;";

            using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
            {
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                //MessageBox.Show("Data Retrieved!"); // Debugging step

                if (dt.Rows.Count > 0)
                {
                    pieChart1.Series.Clear(); // Clear existing series

                    foreach (DataRow row in dt.Rows)
                    {
                        pieChart1.Series.Add(new PieSeries
                        {
                            Title = row["Region Name"].ToString(),
                            Values = new ChartValues<double> { Convert.ToDouble(row["Total Tourists"]) }
                        });
                    }

                    pieChart1.LegendLocation = LegendLocation.Right; // Set legend location
                    pieChart1.Visibility = System.Windows.Visibility.Visible; // Make sure the chart is visible
                    MessageBox.Show("Data Retrieved and Chart Updated! "); // Debugging step
                }
                else
                {
                    MessageBox.Show("No data found for the query."); // Debugging step
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
