﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Budget : Form
    {
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";


        public Budget()
        {
            InitializeComponent();


        }

        private void Budget_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            LoadDB();

        }

        private bool ValidateInput()
        {


            if (!decimal.TryParse(txtLease.Text, out _))
            {
                MessageBox.Show("Please enter a valid lease amount.");
                return false;
            }

            if (!decimal.TryParse(txtCosts.Text, out _))
            {
                MessageBox.Show("Please enter valid operating costs.");
                return false;
            }

            return true;
        }

        private void DelfromDB()
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            // Get the selected row's data
            var selectedRow = dataGridView1.SelectedRows[0];
            int budgetID = Convert.ToInt32(selectedRow.Cells["Budget_ID"].Value);
            string lease = selectedRow.Cells["Lease"].Value.ToString();
            string operatingCosts = selectedRow.Cells["Operating_Costs"].Value.ToString();
            DateTime date = Convert.ToDateTime(selectedRow.Cells["Date"].Value);
            string regionName = selectedRow.Cells["Province"].Value.ToString();

            using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Budget WHERE Budget_ID = @Budget_ID", conn);
                cmd.Parameters.AddWithValue("@Budget_ID", budgetID);
                cmd.ExecuteNonQuery();
            }

            // Display a message box with details of the deleted item
            string message = $"Deleted Budget Item:\n" +
                             $"Budget ID: {budgetID}\n" +
                             $"Lease: {lease}\n" +
                             $"Operating Costs: {operatingCosts}\n" +
                             $"Date: {date.ToShortDateString()}\n" +
                             $"Province: {regionName}";

            MessageBox.Show(message, "Item Deleted");

            LoadDB(); // Refresh the display
        }
        private void updateDB()
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to update.");
                return;
            }

            // Get selected row data
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int id = Convert.ToInt32(selectedRow.Cells["Budget_ID"].Value);
            string lease = selectedRow.Cells["Lease"].Value.ToString();
            string operatingCosts = selectedRow.Cells["Operating_Costs"].Value.ToString();
            DateTime date = Convert.ToDateTime(selectedRow.Cells["Date"].Value);
            string regionName = selectedRow.Cells["Province"].Value.ToString();

            // Open UpdateBudgetForm with selected row data
            UpdateBudgetForm updateForm = new UpdateBudgetForm(id, lease, operatingCosts, date, regionName, connectionString);
            updateForm.ShowDialog();

            // Refresh the display after updating
            LoadDB();
        }

        private void addInDb()
        {
            if (!ValidateInput()) return;

            string regionName = txtProvince_Add.Text;

            if (string.IsNullOrEmpty(regionName))
            {
                MessageBox.Show("Please enter a region/province name.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();


                decimal lease = decimal.Parse(txtLease.Text);
                decimal operatingCosts = decimal.Parse(txtCosts.Text);
                DateTime date = monthCalendar1.SelectionStart;
                bool approved = checkBox1.Checked;

                SqlCommand cmd = new SqlCommand("INSERT INTO Budget (Lease, Operating_Costs, Date, Province) VALUES (@Lease, @Operating_Costs, @Date, @Region_Name)", conn);

                cmd.Parameters.AddWithValue("@Lease", lease);
                cmd.Parameters.AddWithValue("@Operating_Costs", operatingCosts);
                cmd.Parameters.AddWithValue("@Date", date);
                cmd.Parameters.AddWithValue("@Region_Name", regionName);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Budget added successfully.");
            LoadDB();
        }

        private void LoadDB()
        {

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                // Query to filter regions based on the selected province
                string query = @"
            SELECT * 
            FROM Budget";

                SqlCommand cmd = new SqlCommand(query, conn);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }


        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor; 
                }

                
                LoadTheme(control);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addInDb();
        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString() => Text;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            updateDB();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DelfromDB();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void btn_Filter_Budget_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }    
}

