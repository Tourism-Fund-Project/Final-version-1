﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Tourist_Attractions : Form
    {
        public Tourist_Attractions()
        {
            InitializeComponent();
            TouristAttractionDgv.CellClick += TouristAttractionDgv_CellContentClick;

            // 
        }
        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";

        private void Tourist_Attractions_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            PopulateComboBoxes();
            LoadTouristAttractionDB();
            LoadCategories();
            //cbx_Filter_TACategory.SelectedIndexChanged += cbx_Filter_TACategory_SelectedIndexChanged;

        }
        private void PopulateComboBoxes()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cbxRegion.Items.AddRange(provinces);
            cbxRegion2Add.Items.AddRange(provinces);

            string[] CategoriesTA = { "Museums and architecture", "Cultural", "Nature", "Wildlife and Plant Life", "Shopping and Leisure", "Amusement Parks and Resorts", "Political Significance" };
            cbxCategory.Items.AddRange(CategoriesTA);
            //cbx_Filter_TACategory.Items.AddRange(CategoriesTA);
        }

        private void LoadTouristAttractionDB()
        {
            string query = @"
    SELECT 
        TA.TouristAttraction_ID,
        TA.Name AS Name,
        TA.Description,
        TA.Revenue,
        CT.Name AS CategoryName,
        R.Zip_Code AS Region_Zip_Code,
        AF.[Attraction Development Fee] AS DevelopmentFee,
        TA.Province AS ProvinceName
    FROM 
        dbo.TouristAttraction TA
    LEFT JOIN 
        dbo.Category_TA CT ON TA.Category_ID = CT.Category_TA_ID
    LEFT JOIN 
        dbo.Regions R ON TA.Region_ID = R.Region_ID
    LEFT JOIN 
        dbo.Access_Funds AF ON TA.AccessFunds_ID = AF.AccessFunds_ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();
                adapter.Fill(table);

                TouristAttractionDgv.DataSource = table;
            }

        }

        private void LoadCategories()
        {
            string query = @"
    SELECT DISTINCT 
        CT.Name AS CategoryName
    FROM 
        dbo.Category_TA CT";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();
                adapter.Fill(table);

                if (table.Rows.Count > 0)
                {
                    cbx_Filter_TACategory.DataSource = table;
                    cbx_Filter_TACategory.DisplayMember = "CategoryName";
                    cbx_Filter_TACategory.ValueMember = "CategoryName";
                }
                else
                {
                    MessageBox.Show("No categories found.");
                }
            }
        }



        private void LoadTouristAttractionsByCategory(string categoryName = null)
        {
            string query = @"
    SELECT 
        TA.TouristAttraction_ID,
        TA.Name AS Name,
        TA.Description,
        TA.Revenue,
        CT.Name AS CategoryName,
        R.Zip_Code AS Region_Zip_Code,
        AF.[Attraction Development Fee] AS DevelopmentFee,
        TA.Province AS ProvinceName
    FROM 
        dbo.TouristAttraction TA
    LEFT JOIN 
        dbo.Category_TA CT ON TA.Category_ID = CT.Category_TA_ID
    LEFT JOIN 
        dbo.Regions R ON TA.Region_ID = R.Region_ID
    LEFT JOIN 
        dbo.Access_Funds AF ON TA.AccessFunds_ID = AF.AccessFunds_ID
    WHERE 
        (@CategoryName IS NULL OR CT.Name = @CategoryName)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.SelectCommand.Parameters.AddWithValue("@CategoryName", string.IsNullOrWhiteSpace(categoryName) ? (object)DBNull.Value : categoryName);

                DataTable table = new DataTable();
                adapter.Fill(table);

                TouristAttractionDgv.DataSource = table;

                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("No tourist attractions found.");
                }
            }
        }


        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }
        private void ClearTextBoxes()
        {
            txtName.Clear();
            txtDescription.Clear();
            txtRevenue.Clear();
            txtAccessFunds.Clear();
            txt_Zip.Clear();

            //cbxRegion2Add.SelectedIndex = -1;
            //cbxCategory.SelectedIndex = -1;
            //cbxRegion.SelectedIndex = -1; // Reset ComboBox selection if needed
        }

        private void SearchTouristAttractionsByName(string searchName)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SearchTouristAttractionsByName", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameter
                cmd.Parameters.AddWithValue("@SearchName", string.IsNullOrWhiteSpace(searchName) ? (object)DBNull.Value : searchName);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                connection.Open();
                adapter.Fill(dt);
                connection.Close();

                // Bind the results to your DataGridView
                TouristAttractionDgv.DataSource = dt;
            }
        }
        private void deletefromTA()
        {
            if (TouristAttractionDgv.SelectedRows.Count > 0)
            {
                // Hide the selection error label if a row is selected
                label7.Visible = false;

                // Retrieve the selected row from the DataGridView
                DataGridViewRow selectedAttraction = TouristAttractionDgv.SelectedRows[0];
                int touristAttractionID = Convert.ToInt32(selectedAttraction.Cells["TouristAttraction_ID"].Value);

                // Confirm deletion with the user
                DialogResult result = MessageBox.Show("Are you sure you want to delete this attraction?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    // SQL delete query
                    string deleteQuery = "DELETE FROM dbo.TouristAttraction WHERE TouristAttraction_ID = @AttractionID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        try
                        {
                            SqlCommand cmd = new SqlCommand(deleteQuery, connection);
                            cmd.Parameters.AddWithValue("@AttractionID", touristAttractionID);

                            connection.Open();
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected > 0 ? "Attraction deleted successfully!" : "Failed to delete attraction");

                            // Refresh the DataGridView to reflect the deletion
                            LoadTouristAttractionDB(); // Ensure this method reloads data into the DataGridView
                            ClearTextBoxes();
                           
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
            }
            else
            {
                label7.Visible = true;
                label7.Text = "Please click on a Tourist Attraction to delete";
            }


        }

        private void UpdateTouristAttraction()
        {
            if (TouristAttractionDgv.SelectedRows.Count > 0)
            {
                // Retrieve the selected row from the DataGridView
                DataGridViewRow selectedAttraction = TouristAttractionDgv.SelectedRows[0];
                int touristAttractionID;

                // Validate TouristAttraction_ID
                if (!int.TryParse(selectedAttraction.Cells["TouristAttraction_ID"].Value.ToString(), out touristAttractionID))
                {
                    MessageBox.Show("Invalid Tourist Attraction ID. Please select a valid row.");
                    return;
                }

                // Validate inputs
                if (string.IsNullOrWhiteSpace(txtName.Text) ||
                    string.IsNullOrWhiteSpace(txtDescription.Text) ||
                    !decimal.TryParse(txtRevenue.Text, out decimal revenue) ||
                    !decimal.TryParse(txtAccessFunds.Text, out decimal accessFunds) ||
                    cbxRegion2Add.SelectedItem == null ||
                    cbxCategory.SelectedItem == null ||
                    string.IsNullOrWhiteSpace(txt_Zip.Text))
                {
                    MessageBox.Show("Please ensure all fields are correctly filled.");
                    return;
                }

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("UpdateTouristAttraction1", connection)
                        {
                            CommandType = CommandType.StoredProcedure
                        };
                        cmd.Parameters.AddWithValue("@AttractionID", touristAttractionID);
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                        cmd.Parameters.AddWithValue("@Revenue", revenue);
                        cmd.Parameters.AddWithValue("@Province", cbxRegion2Add.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@CategoryName", cbxCategory.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ZipCode", txt_Zip.Text);
                        cmd.Parameters.AddWithValue("@AccessFunds", accessFunds);

                        connection.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Tourist attraction updated successfully!");

                        ClearTextBoxes();
                        LoadTouristAttractionDB();
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("A database error occurred: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a Tourist Attraction to update.");
            }
        }


        

        private void SearchTouristAttractionsByProvinces(string searchName)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SearchTouristAttractionsByProvinces", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameter
                cmd.Parameters.AddWithValue("@SearchName", string.IsNullOrWhiteSpace(searchName) ? (object)DBNull.Value : searchName);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                connection.Open();
                adapter.Fill(dt);
                connection.Close();

                // Bind the results to your DataGridView
                TouristAttractionDgv.DataSource = dt;
            }
        }

        private void AddTouristAttraction()
        {
            // Validate inputs
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtDescription.Text) ||
                !decimal.TryParse(txtRevenue.Text, out decimal revenue) ||
                !decimal.TryParse(txtAccessFunds.Text, out decimal accessFunds) ||
                cbxRegion2Add.SelectedItem == null ||
                cbxCategory.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txt_Zip.Text))
            {
                MessageBox.Show("Please ensure all fields are correctly filled.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("AddTouristAttraction", connection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@Revenue", revenue);
                    cmd.Parameters.AddWithValue("@Province", cbxRegion2Add.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@CategoryName", cbxCategory.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@ZipCode", txt_Zip.Text);
                    cmd.Parameters.AddWithValue("@AccessFunds", accessFunds);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Tourist attraction added successfully!");
                    
                    ClearTextBoxes();
                    LoadTouristAttractionDB();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("A database error occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }


        private void AddTouristAttraction1()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddTouristAttraction", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@Revenue", decimal.Parse(txtRevenue.Text));
                cmd.Parameters.AddWithValue("@Province", cbxRegion2Add.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@CategoryName", cbxCategory.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@ZipCode", txt_Zip.Text);
                cmd.Parameters.AddWithValue("@AccessFunds", decimal.Parse(txtAccessFunds.Text));

                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Tourist attraction added successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddTouristAttraction();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            deletefromTA();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateTouristAttraction();
        }
        private void FilterTouristAttractions(string name, string province, string category)
        {
            string query = @"
    SELECT 
        TA.TouristAttraction_ID,
        TA.Name AS Name,
        TA.Description,
        TA.Revenue,
        CT.Name AS CategoryName,
        R.Zip_Code AS Region_Zip_Code,
        AF.[Attraction Development Fee] AS DevelopmentFee,
        TA.Province AS ProvinceName
    FROM 
        dbo.TouristAttraction TA
    LEFT JOIN 
        dbo.Category_TA CT ON TA.Category_ID = CT.Category_TA_ID
    LEFT JOIN 
        dbo.Regions R ON TA.Region_ID = R.Region_ID
    LEFT JOIN 
        dbo.Access_Funds AF ON TA.AccessFunds_ID = AF.AccessFunds_ID
    WHERE 
        (@Name IS NULL OR TA.Name LIKE '%' + @Name + '%') AND
        (@ProvinceName IS NULL OR TA.Province = @ProvinceName) AND
        (@CategoryName IS NULL OR CT.Name = @CategoryName)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                adapter.SelectCommand.Parameters.AddWithValue("@Name", string.IsNullOrWhiteSpace(name) ? (object)DBNull.Value : name);
                adapter.SelectCommand.Parameters.AddWithValue("@ProvinceName", string.IsNullOrWhiteSpace(province) ? (object)DBNull.Value : province);
                adapter.SelectCommand.Parameters.AddWithValue("@CategoryName", string.IsNullOrWhiteSpace(category) ? (object)DBNull.Value : category);

                DataTable table = new DataTable();
                adapter.Fill(table);

                TouristAttractionDgv.DataSource = table;

                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("No tourist attractions found.");
                }
            }

        }
        private void btn_Filter_TA_Click(object sender, EventArgs e)
        {
            string selectedProvince = cbxRegion.SelectedItem?.ToString();
            string searchName = txt_Filter_TAName.Text;
            string selectedCategory = cbx_Filter_TACategory.SelectedValue?.ToString();

            // Check if any filters are provided
            if (!string.IsNullOrWhiteSpace(searchName) || !string.IsNullOrWhiteSpace(selectedProvince) || !string.IsNullOrWhiteSpace(selectedCategory))
            {
                // Call a method to apply all filters together
                FilterTouristAttractions(searchName, selectedProvince, selectedCategory);
            }
            else
            {
                // Load all tourist attractions if no filters are applied
                LoadTouristAttractionsByCategory(null);
            }
        }

        private void TouristAttractionDgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                if (TouristAttractionDgv.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = TouristAttractionDgv.SelectedRows[0];

                    // Load the values into the corresponding textboxes
                    txtName.Text = selectedRow.Cells["Name"].Value.ToString();
                    txtDescription.Text = selectedRow.Cells["Description"].Value.ToString();
                    txtRevenue.Text = selectedRow.Cells["Revenue"].Value.ToString();
                    txt_Zip.Text = selectedRow.Cells["Region_Zip_Code"].Value.ToString();
                    txtAccessFunds.Text = selectedRow.Cells["DevelopmentFee"].Value.ToString();

                    // Ensure the combo boxes select the correct values
                    string categoryName = selectedRow.Cells["CategoryName"].Value.ToString();
                    if (cbxCategory.Items.Contains(categoryName))
                    {
                        cbxCategory.SelectedItem = categoryName;
                    }

                    string provinceName = selectedRow.Cells["ProvinceName"].Value.ToString();
                    if (cbxRegion2Add.Items.Contains(provinceName))
                    {
                        cbxRegion2Add.SelectedItem = provinceName;
                    }
                }
            
        }

        private void cbxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Catefogory2maintain = cbxCategory.SelectedItem.ToString();
        }

        private void cbxRegion2Add_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProvinceToMaintain = cbxRegion2Add.SelectedItem.ToString();
        }

        private void cbxRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string ProvinceToMaintain = cbxRegion.SelectedItem.ToString();
        }

        private void cbx_Filter_TACategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string Catefogory2maintain = cbx_Filter_TACategory.SelectedItem.ToString();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cbx_Filter_TACategory.SelectedIndex = -1;
            cbxRegion2Add.SelectedIndex = -1;
            txt_Filter_TAName.Clear();

            LoadTouristAttractionDB();

            
            
        }
    }

}



