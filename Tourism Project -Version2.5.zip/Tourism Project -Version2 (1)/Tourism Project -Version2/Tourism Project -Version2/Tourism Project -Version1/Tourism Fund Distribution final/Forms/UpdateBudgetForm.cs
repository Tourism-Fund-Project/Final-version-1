﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class UpdateBudgetForm : Form
    {
        private int budgetID;
        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";


        public UpdateBudgetForm(int id, string lease, string operatingCosts, DateTime date, string regionName, string connString)
         {
             InitializeComponent();
             budgetID = id;
             
             txtLease.Text = lease;
             txtCosts.Text = operatingCosts;
             txtName.Text = regionName;
         }           
        

        private void DisplayUpdatedData(decimal lease, decimal operatingCosts, DateTime date, string regionName)
        {
            listBoxPreview.Items.Add("Updated Data:");
            listBoxPreview.Items.Add($"Lease: {lease}");
            listBoxPreview.Items.Add($"Operating Costs: {operatingCosts}");
            listBoxPreview.Items.Add($"Date: {date.ToShortDateString()}");
            listBoxPreview.Items.Add($"Region Name: {regionName}");
        }

        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor; // Set to the default primary color
                }

                // Recursive call to handle nested controls
                LoadTheme(control);
            }

        }

        private bool ValidateInput()
        {
            if (!decimal.TryParse(txtLease.Text, out _))
            {
                MessageBox.Show("Please enter a valid lease amount.");
                return false;
            }

            if (!decimal.TryParse(txtCosts.Text, out _))
            {
                MessageBox.Show("Please enter valid operating costs.");
                return false;
            }

            return true;
        }
        private void btnChanges_Click(object sender, EventArgs e)
        {
            decimal updatedLease = decimal.Parse(txtLease.Text);
            decimal updatedOperatingCosts = decimal.Parse(txtCosts.Text);
            DateTime updatedDate = monthCalendar1.SelectionStart;
            string updatedRegionName = txtName.Text;


            DisplayUpdatedData(updatedLease, updatedOperatingCosts, updatedDate, updatedRegionName);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                decimal lease = decimal.Parse(txtLease.Text);
                decimal operatingCosts = decimal.Parse(txtCosts.Text);
                DateTime date = monthCalendar1.SelectionStart;
                string regionName = txtName.Text;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Budget SET Lease = @Lease, Operating_Costs = @Operating_Costs, Date = @Date, Province = @Region_Name WHERE Budget_ID = @Budget_ID", conn);
                    cmd.Parameters.AddWithValue("@Lease", lease);
                    cmd.Parameters.AddWithValue("@Operating_Costs", operatingCosts);
                    cmd.Parameters.AddWithValue("@Date", date);
                    cmd.Parameters.AddWithValue("@Region_Name", regionName);
                    cmd.Parameters.AddWithValue("@Budget_ID", budgetID);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Budget updated successfully.");
                this.Close();
            }
        }

        private void UpdateBudgetForm_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
        }
    }
}
