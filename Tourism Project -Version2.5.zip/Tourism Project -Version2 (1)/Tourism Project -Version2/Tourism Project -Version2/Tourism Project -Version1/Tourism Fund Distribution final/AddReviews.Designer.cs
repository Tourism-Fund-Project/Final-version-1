﻿
namespace Tourism_Fund_Distribution_final
{
    partial class AddReviews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_AttractionName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_NumTourists = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_PerformanceRank = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_AttractionDev = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePickerReviewDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_AttractionSupervisor_SName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_AttractionSupervisor_FName = new System.Windows.Forms.TextBox();
            this.btn_SubmitReview = new System.Windows.Forms.Button();
            this.txt_Province = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbxDevelopmentName = new System.Windows.Forms.ComboBox();
            this.cbxSupervisorFullName = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 49);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attraction Name";
            // 
            // txt_AttractionName
            // 
            this.txt_AttractionName.Location = new System.Drawing.Point(242, 45);
            this.txt_AttractionName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AttractionName.Name = "txt_AttractionName";
            this.txt_AttractionName.Size = new System.Drawing.Size(282, 26);
            this.txt_AttractionName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 114);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Number of Tourists";
            // 
            // txt_NumTourists
            // 
            this.txt_NumTourists.Location = new System.Drawing.Point(242, 109);
            this.txt_NumTourists.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_NumTourists.Name = "txt_NumTourists";
            this.txt_NumTourists.Size = new System.Drawing.Size(282, 26);
            this.txt_NumTourists.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 174);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(142, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Performance Rank";
            // 
            // txt_PerformanceRank
            // 
            this.txt_PerformanceRank.Location = new System.Drawing.Point(242, 169);
            this.txt_PerformanceRank.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_PerformanceRank.Name = "txt_PerformanceRank";
            this.txt_PerformanceRank.Size = new System.Drawing.Size(282, 26);
            this.txt_PerformanceRank.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 246);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(176, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Attraction Development";
            // 
            // txt_AttractionDev
            // 
            this.txt_AttractionDev.Location = new System.Drawing.Point(793, 219);
            this.txt_AttractionDev.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AttractionDev.Name = "txt_AttractionDev";
            this.txt_AttractionDev.Size = new System.Drawing.Size(282, 26);
            this.txt_AttractionDev.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxDevelopmentName);
            this.groupBox1.Controls.Add(this.dateTimePickerReviewDate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txt_PerformanceRank);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_AttractionName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_NumTourists);
            this.groupBox1.Location = new System.Drawing.Point(60, 48);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(678, 363);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Review details";
            // 
            // dateTimePickerReviewDate
            // 
            this.dateTimePickerReviewDate.Location = new System.Drawing.Point(242, 300);
            this.dateTimePickerReviewDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReviewDate.Name = "dateTimePickerReviewDate";
            this.dateTimePickerReviewDate.Size = new System.Drawing.Size(282, 26);
            this.dateTimePickerReviewDate.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(155, 300);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Date";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbxSupervisorFullName);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(60, 435);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(678, 136);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Attraction Supervisor details";
            // 
            // txt_AttractionSupervisor_SName
            // 
            this.txt_AttractionSupervisor_SName.Location = new System.Drawing.Point(793, 330);
            this.txt_AttractionSupervisor_SName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AttractionSupervisor_SName.Name = "txt_AttractionSupervisor_SName";
            this.txt_AttractionSupervisor_SName.Size = new System.Drawing.Size(282, 26);
            this.txt_AttractionSupervisor_SName.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 58);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = " Name & Surname";
            // 
            // txt_AttractionSupervisor_FName
            // 
            this.txt_AttractionSupervisor_FName.Location = new System.Drawing.Point(793, 272);
            this.txt_AttractionSupervisor_FName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AttractionSupervisor_FName.Name = "txt_AttractionSupervisor_FName";
            this.txt_AttractionSupervisor_FName.Size = new System.Drawing.Size(282, 26);
            this.txt_AttractionSupervisor_FName.TabIndex = 3;
            // 
            // btn_SubmitReview
            // 
            this.btn_SubmitReview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SubmitReview.Location = new System.Drawing.Point(302, 627);
            this.btn_SubmitReview.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_SubmitReview.Name = "btn_SubmitReview";
            this.btn_SubmitReview.Size = new System.Drawing.Size(182, 42);
            this.btn_SubmitReview.TabIndex = 26;
            this.btn_SubmitReview.Text = "Submit";
            this.btn_SubmitReview.UseVisualStyleBackColor = true;
            this.btn_SubmitReview.Click += new System.EventHandler(this.btn_SubmitReview_Click);
            // 
            // txt_Province
            // 
            this.txt_Province.Location = new System.Drawing.Point(862, 399);
            this.txt_Province.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Province.Name = "txt_Province";
            this.txt_Province.Size = new System.Drawing.Size(282, 26);
            this.txt_Province.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(750, 399);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Province";
            // 
            // cbxDevelopmentName
            // 
            this.cbxDevelopmentName.FormattingEnabled = true;
            this.cbxDevelopmentName.Location = new System.Drawing.Point(242, 238);
            this.cbxDevelopmentName.Name = "cbxDevelopmentName";
            this.cbxDevelopmentName.Size = new System.Drawing.Size(282, 28);
            this.cbxDevelopmentName.TabIndex = 12;
            // 
            // cbxSupervisorFullName
            // 
            this.cbxSupervisorFullName.FormattingEnabled = true;
            this.cbxSupervisorFullName.Location = new System.Drawing.Point(242, 58);
            this.cbxSupervisorFullName.Name = "cbxSupervisorFullName";
            this.cbxSupervisorFullName.Size = new System.Drawing.Size(282, 28);
            this.cbxSupervisorFullName.TabIndex = 6;
            // 
            // AddReviews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.btn_SubmitReview);
            this.Controls.Add(this.txt_Province);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txt_AttractionSupervisor_SName);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt_AttractionDev);
            this.Controls.Add(this.txt_AttractionSupervisor_FName);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "AddReviews";
            this.Text = "AddReviews";
            this.Load += new System.EventHandler(this.AddReviews_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_AttractionName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_NumTourists;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_PerformanceRank;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_AttractionDev;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePickerReviewDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_AttractionSupervisor_SName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_AttractionSupervisor_FName;
        private System.Windows.Forms.Button btn_SubmitReview;
        private System.Windows.Forms.TextBox txt_Province;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbxDevelopmentName;
        private System.Windows.Forms.ComboBox cbxSupervisorFullName;
    }
}