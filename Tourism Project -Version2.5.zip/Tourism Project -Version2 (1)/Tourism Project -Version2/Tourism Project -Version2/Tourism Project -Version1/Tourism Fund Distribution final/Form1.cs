﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final
{
    public partial class Form1 : Form
    {
        //Move form
        public Point mouseLocation;

        //Fields
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;

        
        //constructor
        public Form1()
        {
            InitializeComponent();
            AdjustAccessControls();
            random = new Random();
        }
        // Property to set the username
        public string userName { get; set; }
        
        //Controls access to forms depending on login details
        private void AdjustAccessControls()
        {
            if (UserSession.UserRole == "AttractionSupervisor")
            {
                btnAF.Enabled = false;
                btnBudget.Enabled = false;
                btnNeeds.Enabled = false;
                btnRegionMenu.Enabled = false;
                btnReport.Enabled = false;
                btnTA.Enabled = false;
            }
            else if (UserSession.UserRole == "FinancialOfficer")
            {
                btnNeeds.Enabled = false;
                btnRegionMenu.Enabled = false;
                btnReport.Enabled = false;
                btnTA.Enabled = false;
                btnReviews.Enabled = false;
            }
            else if (UserSession.UserRole == "SystemAdmin")
            {
                btnNeeds.Enabled = true;
                btnRegionMenu.Enabled = true;
                btnReport.Enabled = true;
                btnTA.Enabled = true;
                btnReviews.Enabled = true;
                btnReport.Enabled = true;
                btnAF.Enabled = true;
            }
        }
        int counter = 0;
        //Methods
        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColour.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColour.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColour.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    this.btnRegionMenu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColour.ChangeColourBrightness(color, -0.3);
                    ThemeColour.PrimaryColor = color;
                    ThemeColour.SecondaryColor = ThemeColour.ChangeColourBrightness(color, -0.3);
                }
            }
        }
        private void DisableButton()
        {
            foreach (Control previousBtn in panelMenu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 77);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }

        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktop.Controls.Add(childForm);
            this.panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
        }


        private void btnRegionMenu_Click(object sender, EventArgs e)
        {
            if (UserSession.UserRole == "SystemAdmin")
            {
                OpenChildForm(new Forms.Regions(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (UserSession.UserRole == "SystemAdmin")
            {
                OpenChildForm(new Forms.Tourist_Attractions(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (UserSession.UserRole == "SystemAdmin")
            {
                OpenChildForm(new Forms.Needs(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }
           
        }

        private void btnReviews_Click(object sender, EventArgs e)
        {
            
            if (UserSession.UserRole == "AttractionSupervisor" || UserSession.UserRole == "SystemAdmin")
            {
                // Open the Reviews form
                OpenChildForm(new Forms.Reviews(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }
        }

        private void btnBudget_Click(object sender, EventArgs e)
        {
            if (UserSession.UserRole == "FinancialOfficer" || UserSession.UserRole == "SystemAdmin")
            {
                OpenChildForm(new Forms.Budget(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }
            
        }

        private void btnAF_Click(object sender, EventArgs e)
        {
            if (UserSession.UserRole == "FinancialOfficer" || UserSession.UserRole == "SystemAdmin")
            {
                OpenChildForm(new Forms.AccessFunds(), sender);
            }
            else
            {
                MessageBox.Show("You do not have access to this form.");
            }
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void mouse_Down(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void mouse_Move(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.Reports(), sender);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
           
            if(counter < 5)
            {
                pictureBox2.Image = imageList1.Images[counter];
                counter++;
            }
            else
            {
                counter = 0;
            }
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            // Set the label text to show the username
            lblUser.Text = $"Welcome, {UserSession.UserName}";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            this.Hide();

            // Clear user session data if necessary
            UserSession.UserRole = null;
            UserSession.UserName = null;

            
            Login loginForm = new Login();
            loginForm.Show();
            this.Close();
        }
    }
}
