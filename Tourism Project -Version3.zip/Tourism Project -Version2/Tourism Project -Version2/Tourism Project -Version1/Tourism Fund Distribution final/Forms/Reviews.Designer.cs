﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Reviews
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridViewReviews = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cbxRegions1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewTA = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_Filter_Reviews = new System.Windows.Forms.Button();
            this.hScrollBarRank = new System.Windows.Forms.HScrollBar();
            this.txt_NumTourists = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxProvinces4Reviews = new System.Windows.Forms.ComboBox();
            this.panel1Reviews = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReviews)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTA)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panel1Reviews.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridViewReviews);
            this.groupBox1.Location = new System.Drawing.Point(50, 668);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(770, 242);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Reviews";
            // 
            // dataGridViewReviews
            // 
            this.dataGridViewReviews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReviews.Location = new System.Drawing.Point(9, 34);
            this.dataGridViewReviews.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewReviews.Name = "dataGridViewReviews";
            this.dataGridViewReviews.RowHeadersWidth = 62;
            this.dataGridViewReviews.Size = new System.Drawing.Size(752, 198);
            this.dataGridViewReviews.TabIndex = 21;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(602, 606);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(218, 42);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add Reviews";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cbxRegions1
            // 
            this.cbxRegions1.FormattingEnabled = true;
            this.cbxRegions1.Location = new System.Drawing.Point(615, 40);
            this.cbxRegions1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbxRegions1.Name = "cbxRegions1";
            this.cbxRegions1.Size = new System.Drawing.Size(180, 28);
            this.cbxRegions1.TabIndex = 18;
            this.cbxRegions1.SelectedIndexChanged += new System.EventHandler(this.cbxRegions1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(672, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Province";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewTA);
            this.groupBox2.Location = new System.Drawing.Point(50, 87);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(770, 308);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tourist Attractions";
            // 
            // dataGridViewTA
            // 
            this.dataGridViewTA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTA.Location = new System.Drawing.Point(26, 29);
            this.dataGridViewTA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewTA.Name = "dataGridViewTA";
            this.dataGridViewTA.RowHeadersWidth = 62;
            this.dataGridViewTA.Size = new System.Drawing.Size(735, 254);
            this.dataGridViewTA.TabIndex = 21;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel1Reviews);
            this.groupBox3.Location = new System.Drawing.Point(50, 405);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(435, 253);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Tourist Attractions Reviews by";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btn_Filter_Reviews
            // 
            this.btn_Filter_Reviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_Reviews.Location = new System.Drawing.Point(205, 177);
            this.btn_Filter_Reviews.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Filter_Reviews.Name = "btn_Filter_Reviews";
            this.btn_Filter_Reviews.Size = new System.Drawing.Size(218, 42);
            this.btn_Filter_Reviews.TabIndex = 23;
            this.btn_Filter_Reviews.Text = "Filter";
            this.btn_Filter_Reviews.UseVisualStyleBackColor = true;
            this.btn_Filter_Reviews.Click += new System.EventHandler(this.btn_Filter_Reviews_Click);
            // 
            // hScrollBarRank
            // 
            this.hScrollBarRank.LargeChange = 1;
            this.hScrollBarRank.Location = new System.Drawing.Point(242, 38);
            this.hScrollBarRank.Maximum = 10;
            this.hScrollBarRank.Name = "hScrollBarRank";
            this.hScrollBarRank.Size = new System.Drawing.Size(148, 15);
            this.hScrollBarRank.TabIndex = 5;
            this.hScrollBarRank.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBarRank_Scroll);
            // 
            // txt_NumTourists
            // 
            this.txt_NumTourists.Location = new System.Drawing.Point(242, 74);
            this.txt_NumTourists.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_NumTourists.Name = "txt_NumTourists";
            this.txt_NumTourists.Size = new System.Drawing.Size(148, 26);
            this.txt_NumTourists.TabIndex = 3;
            this.txt_NumTourists.TextChanged += new System.EventHandler(this.txt_NumTourists_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 134);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Provinces";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 85);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Number of tourists";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Performance rank";
            // 
            // cbxProvinces4Reviews
            // 
            this.cbxProvinces4Reviews.FormattingEnabled = true;
            this.cbxProvinces4Reviews.Location = new System.Drawing.Point(242, 131);
            this.cbxProvinces4Reviews.Name = "cbxProvinces4Reviews";
            this.cbxProvinces4Reviews.Size = new System.Drawing.Size(151, 28);
            this.cbxProvinces4Reviews.TabIndex = 24;
            this.cbxProvinces4Reviews.SelectedIndexChanged += new System.EventHandler(this.cbxProvinces4Reviews_SelectedIndexChanged);
            // 
            // panel1Reviews
            // 
            this.panel1Reviews.Controls.Add(this.cbxProvinces4Reviews);
            this.panel1Reviews.Controls.Add(this.btn_Filter_Reviews);
            this.panel1Reviews.Controls.Add(this.label2);
            this.panel1Reviews.Controls.Add(this.hScrollBarRank);
            this.panel1Reviews.Controls.Add(this.label3);
            this.panel1Reviews.Controls.Add(this.label4);
            this.panel1Reviews.Controls.Add(this.txt_NumTourists);
            this.panel1Reviews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1Reviews.Location = new System.Drawing.Point(4, 24);
            this.panel1Reviews.Name = "panel1Reviews";
            this.panel1Reviews.Size = new System.Drawing.Size(427, 224);
            this.panel1Reviews.TabIndex = 23;
            this.panel1Reviews.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Reviews
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 915);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbxRegions1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Reviews";
            this.Text = "Reviews";
            this.Load += new System.EventHandler(this.Reviews_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReviews)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTA)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.panel1Reviews.ResumeLayout(false);
            this.panel1Reviews.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox cbxRegions1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewReviews;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewTA;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.HScrollBar hScrollBarRank;
        private System.Windows.Forms.TextBox txt_NumTourists;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Filter_Reviews;
        private System.Windows.Forms.ComboBox cbxProvinces4Reviews;
        private System.Windows.Forms.Panel panel1Reviews;
    }
}