﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
            Panel panelReviews = new Panel();
            panelReviews.AutoScroll = true;

        }
        public void ReloadReviewsDataGrid()
        {
            LoadReviewsDB(); // This method reloads the reviews into the DataGridView
        }

        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";

        private void Reviews_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            LoadTouristAttractionDB();
            PopulateComboBox();

        }

        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cbxRegions1.Items.AddRange(provinces);
            //cmbProvince2.Items.AddRange(provinces);
            cbxProvinces4Reviews.Items.AddRange(provinces);
        }
        private void LoadTouristAttractionDB()
        {
            string query = @"
    SELECT 
        TA.TouristAttraction_ID,
        TA.Name AS Attraction_Name,
        TA.Description,
        TA.Revenue,
        CT.Name AS CategoryName,
        R.Zip_Code AS Region_Zip_Code,
        AF.[Attraction Development Fee] AS DevelopmentFee,
        TA.Province AS ProvinceName
    FROM 
        dbo.TouristAttraction TA
    LEFT JOIN 
        dbo.Category_TA CT ON TA.Category_ID = CT.Category_TA_ID
    LEFT JOIN 
        dbo.Regions R ON TA.Region_ID = R.Region_ID
    LEFT JOIN 
        dbo.Access_Funds AF ON TA.AccessFunds_ID = AF.AccessFunds_ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridViewTA.DataSource = table;
            }

        }
        private void LoadReviewsDB()
        {
           
            string storedProcedure = "GetReviews";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand(storedProcedure, connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Execute the command and fill the data into a DataTable
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        // Bind the DataTable to the DataGridView
                        dataGridViewReviews.DataSource = table;
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors that may occur
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        
       

        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor; // Set to the default primary color
                }

                // Recursive call to handle nested controls
                LoadTheme(control);
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddReviews addReviewForm = new AddReviews(this);
            addReviewForm.ShowDialog();
        }

        private void hScrollBarRank_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void txt_NumTourists_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_Filter_Reviews_Click(object sender, EventArgs e)
        {
            string selectedProvince = cbxProvinces4Reviews.SelectedItem?.ToString();
            int? performanceRank = null;
            int? numberOfTourists = null;

            if (int.TryParse(txt_Filter_PerformanceRank.Text, out int rank))
            {
                performanceRank = rank;
            }

            if (int.TryParse(txt_NumTourists.Text, out int tourists))
            {
                numberOfTourists = tourists;
            }

            // Call the method to filter reviews
            FilterReviews(numberOfTourists, performanceRank, selectedProvince);
        }

        private void FilterReviews(int? numberOfTourists, int? performanceRank, string province)
        {
            // Prepare the stored procedure call
            string storedProcedure = "FilterReviews";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand(storedProcedure, connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Add parameters only if they have values
                        if (numberOfTourists.HasValue)
                        {
                            cmd.Parameters.AddWithValue("@NumberOfTourists", numberOfTourists.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@NumberOfTourists", DBNull.Value);
                        }

                        if (performanceRank.HasValue)
                        {
                            cmd.Parameters.AddWithValue("@PerformanceRank", performanceRank.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@PerformanceRank", DBNull.Value);
                        }

                        if (!string.IsNullOrEmpty(province))
                        {
                            cmd.Parameters.AddWithValue("@Province", province);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@Province", DBNull.Value);
                        }

                        // Execute the command and fill the data into a DataTable
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        // Bind the DataTable to the DataGridView
                        dataGridViewReviews.DataSource = table;
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors that may occur
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void FilterTouristAttractionsByProvince(string province)
        {
            string query = "FilterTouristAttractionsByProvince"; 

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ProvinceName", province);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridViewTA.DataSource = table; 
            }
        }
        private void LoadReviewsByTouristAttractionType(string province)
        {
            string query = "GetReviewsByTouristAttractionType"; // Name of the stored procedure

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ProvinceName", province);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridViewReviews.DataSource = table; // Assuming ReviewsDgv is your DataGridView for reviews
            }
        }
        private void cbxRegions1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxRegions1.SelectedItem != null)
            {
                string selectedProvince = cbxRegions1.SelectedItem.ToString();
                FilterTouristAttractionsByProvince(selectedProvince);

            }
           
        }

        private void cbxProvinces4Reviews_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
