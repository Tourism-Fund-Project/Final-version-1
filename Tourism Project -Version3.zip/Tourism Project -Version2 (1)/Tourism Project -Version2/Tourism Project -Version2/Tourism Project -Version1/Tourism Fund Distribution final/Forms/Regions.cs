﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Regions : Form
    {
        public Regions()
        {
            InitializeComponent();
            //btnAdd.Click += btnAdd_Click;
            dataGridViewRegion.CellClick += dataGridViewRegion_CellContentClick;

            //btnUpdate.Click += btnUpdate_Click;

        }
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";


        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }

        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cbxRegions1.Items.AddRange(provinces);
            //cmbProvince2.Items.AddRange(provinces);
        }

        private void ClearTextBoxes()
        {
            txt_FilterDescription.Clear();
            txt_regionName .Clear();
            txt_regionZip .Clear();
            cbxProvinces2.SelectedIndex = -1;
            //cmb_region.SelectedIndex = -1; // Reset ComboBox selection if needed
        }
        private void Regions_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            
            LoadRegionsDB();
            LoadProvinces();
        }
        private void LoadRegionsDB()
        {
            string query = "GetRegionsWithBudgetProvince";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Assuming 'RegionsDgv' is your DataGridView control
                dataGridViewRegion.DataSource = dataTable;
            }
        }

        private void DeleteRegionfromDB()
        {
            if (dataGridViewRegion.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridViewRegion.SelectedRows[0];
                int regionID = Convert.ToInt32(selectedRow.Cells["Region_ID"].Value);

                // Confirm deletion
                DialogResult result = MessageBox.Show("Are you sure you want to delete this region?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand cmd = new SqlCommand("DeleteRegion", connection);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RegionID", regionID);

                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();

                        // Refresh the DataGridView after deletion
                        LoadRegionsDB();

                        MessageBox.Show("Region deleted successfully.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a region to delete.");
            }
        }
        private void addInDB()
        {
            if (!string.IsNullOrWhiteSpace(txt_regionName.Text) && !string.IsNullOrWhiteSpace(txt_regionZip.Text) && cbxProvinces2.SelectedItem != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("AddRegion", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", txt_regionName.Text);
                    cmd.Parameters.AddWithValue("@ZipCode", txt_regionZip.Text);
                    cmd.Parameters.AddWithValue("@ProvinceName", cbxProvinces2.SelectedItem.ToString());

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();

                    // Refresh the DataGridView after adding
                    LoadRegionsDB();

                    MessageBox.Show("Region added successfully.");
                }
            }
            else
            {
                MessageBox.Show("Please fill in all fields before adding a region.");
            }
        }

        private void updateInDB()
        {

            if (dataGridViewRegion.SelectedRows.Count > 0 && !string.IsNullOrWhiteSpace(txt_regionName.Text) && !string.IsNullOrWhiteSpace(txt_regionZip.Text) && cbxProvinces2.SelectedItem != null)
            {
                // Get the selected Region_ID
                DataGridViewRow selectedRow = dataGridViewRegion.SelectedRows[0];
                int regionID = Convert.ToInt32(selectedRow.Cells["Region_ID"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("UpdateRegion", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@RegionID", regionID);
                    cmd.Parameters.AddWithValue("@Name", txt_regionName.Text);
                    cmd.Parameters.AddWithValue("@ZipCode", txt_regionZip.Text);
                    cmd.Parameters.AddWithValue("@ProvinceName", cbxProvinces2.SelectedItem.ToString());

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();

                    // Refresh the DataGridView after updating
                    LoadRegionsDB();

                    MessageBox.Show("Region updated successfully.");
                }
            }
            else
            {
                MessageBox.Show("Please select a region and fill in all fields before updating.");
            }
        }

        private void LoadProvinces()
        {
            // Example of loading provinces into the ComboBox
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT Province FROM Budget", connection);
                connection.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cbxProvinces2.Items.Add(reader["Province"].ToString());
                    //cbxRegions1.Items.Add(reader["Province"].ToString());
                }
                connection.Close();
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            addInDB();

        }
        private void SearchRegionByZipCode(string zipCode)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SearchRegionsByZipCode", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ZipCode", zipCode);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Bind the DataGridView to the search results
                dataGridViewRegion.DataSource = dt;
            }
        }
        private void btn_Filter_Click(object sender, EventArgs e)
        {
            string zipCode = txt_FilterDescription.Text.Trim();

            if (!string.IsNullOrEmpty(zipCode))
            {
                SearchRegionByZipCode(zipCode);
            }
            else
            {
                MessageBox.Show("Please enter a Zip Code to search.", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteRegionfromDB();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            updateInDB();
        }

        private void dataGridViewRegion_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Get the selected row
                DataGridViewRow row = dataGridViewRegion.Rows[e.RowIndex];

                // Populate textboxes and combobox with the values from the selected row
                txt_regionName.Text = row.Cells["Name"].Value.ToString();
                txt_regionZip.Text = row.Cells["Zip_Code"].Value.ToString();
                cbxProvinces2.SelectedItem = row.Cells["ProvinceName"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadRegionsDB();
        }
    }
}
