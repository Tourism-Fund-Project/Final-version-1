﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
           
        }
        //replace connections here or in each method
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

        private void Reviews_Load(object sender, EventArgs e)
        {
            LoadTheme();
            loadCBXRegions();
            //displayTouristAttractions(string region);
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
           
        }

        private void loadCBXRegions()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North West", "Northern Cape", "Western Cape" };
            cbxRegions1.Items.AddRange(provinces);


            //string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";
            /*
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Region_ID, Name FROM Regions"; 
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataReader reader = command.ExecuteReader();
                    List<string> regions = new List<string>();

                    while (reader.Read())
                    {
                        regions.Add(reader["Name"].ToString());
                    }

                    cbxRegions.DataSource = regions;
                }
                connection.Close();
            }*/

        }
        private void FilterRegionsByProvince(string province)
        {
            // Corrected SQL query using OR conditions for filtering
            string query = @"
            SELECT * FROM TouristAttraction
            WHERE 
            (@selectedProvince = 'Eastern Cape' AND Region_ID BETWEEN 162 AND 171) OR
            (@selectedProvince = 'Free State' AND Region_ID BETWEEN 132 AND 141) OR
            (@selectedProvince = 'Gauteng' AND Region_ID BETWEEN 111 AND 120) OR
            (@selectedProvince = 'KwaZulu-Natal' AND (region_ID BETWEEN 101 AND 110)) OR
            (@selectedProvince = 'Limpopo' AND Region_ID BETWEEN 152 AND 161) OR
            (@selectedProvince = 'Mpumalanga' AND Region_ID BETWEEN 142 AND 151) OR
            (@selectedProvince = 'North West' AND Region_ID BETWEEN 172 AND 181) OR
            (@selectedProvince = 'Northern Cape' AND Region_ID BETWEEN 182 AND 191) OR
            (@selectedProvince = 'Western Cape' AND Region_ID BETWEEN 121 AND 131)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@selectedProvince", province); // Pass the selected province as a parameter

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridViewTA.DataSource = dataTable; // Bind the filtered data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void comboBoxRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Handle the selection change event for the ComboBox
            string selectedProvince = cbxRegions1.SelectedItem.ToString();
            if (!string.IsNullOrEmpty(selectedProvince))
            {
                FilterRegionsByProvince(selectedProvince); // Filter regions based on the selected province
            }
            else
            {
                MessageBox.Show("No province selected");
            }
        }
        private void displayTouristAttractions(string region)
        {
            // Display tourist attractions based on the selected region
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"
                SELECT 
                TA.Name, 
                TA.Description 
                FROM TouristAttraction TA
                WHERE TA.Region_ID = @Region";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Region", region);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewTA.DataSource = dataTable;
                }
                connection.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string selectedRegion = cbxRegions1.SelectedItem?.ToString(); // Use null-conditional operator
            if (!string.IsNullOrEmpty(selectedRegion))
            {
                LoadReviews(selectedRegion);
            }
            else
            {
                MessageBox.Show("Please select a region.");
            }

        }
        private void LoadReviews(string region)
        {
            //string connectionString = "your_connection_string";
            if (!string.IsNullOrEmpty(region))
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = @"
                    SELECT 
                    TA.Name, 
                    TA.Description, 
                    R.Number_of_Tourists, 
                    R.Performance_Rank, 
                    R.Date
                    FROM TouristAttraction TA
                    LEFT JOIN Reviews R ON TA.Tourist_ID = R.TouristAttraction_ID
                    WHERE TA.Region_ID = @Region";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            // Assuming 'region' is a string, but if it's an ID, it should be int and converted
                            command.Parameters.AddWithValue("@Region", region);

                            SqlDataAdapter adapter = new SqlDataAdapter(command);
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            dataGridViewTA.DataSource = dataTable; // Bind the result to DataGridView
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while loading reviews: " + ex.Message);
                    }
                    finally
                    {
                        connection.Close(); // Ensure the connection is closed even if an exception occurs
                    }
                }
            }
            else
            {
                MessageBox.Show("No valid region selected.");
            }
        }
    }
}
