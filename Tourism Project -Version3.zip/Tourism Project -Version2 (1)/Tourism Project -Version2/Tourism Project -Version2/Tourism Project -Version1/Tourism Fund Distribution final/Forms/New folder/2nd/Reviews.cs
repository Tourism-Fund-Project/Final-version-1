﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
           
        }
        //replace connections here or in each method
        string connectionString = " Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

        private void Reviews_Load(object sender, EventArgs e)
        {
            LoadTheme();
            loadCBXRegions();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
           
        }

        private void loadCBXRegions()
        {
            string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Region_ID, Name FROM Regions"; 
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataReader reader = command.ExecuteReader();
                    List<string> regions = new List<string>();

                    while (reader.Read())
                    {
                        regions.Add(reader["Name"].ToString());
                    }

                    cbxRegions.DataSource = regions;
                }
                connection.Close();
            }

        }

        private void comboBoxRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRegion = cbxRegions.SelectedItem.ToString();
            displayTouristAttractions(selectedRegion);
        }
        private void displayTouristAttractions(string region)
        {
            string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT Name, Description, Name FROM TouristAttraction JOIN Category_TA CTA  Category_ID = CTA.Id WHERE TA.Region = @Region";  
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Region", region);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewTA.DataSource = dataTable; 
                }
                connection.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string selectedRegion = cbxRegions.SelectedItem.ToString();
            LoadReviews(selectedRegion);
        }
        private void LoadReviews(string region)
        {
            string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";
            if(cbxRegions.SelectedValue != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                    SELECT 
                        Name, 
                        Description, 
                        Name, 
                        Number_Of_Tourists, 
                        Performance_Rank, 
                        Date
                        FROM TouristAttraction
                        JOIN Category_TA CTA ON TA.Category_ID = CTA.Id
                        LEFT JOIN Reviews R ON TA.Id = R.TouristAttraction_ID
                        WHERE TA.Region = @Region"; 

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Region", region);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewTA.DataSource = dataTable;
                    }
                    connection.Close();
                }
            }
            else
            {
                MessageBox.Show("Reviews added");
            }
           
        }
    }
}
