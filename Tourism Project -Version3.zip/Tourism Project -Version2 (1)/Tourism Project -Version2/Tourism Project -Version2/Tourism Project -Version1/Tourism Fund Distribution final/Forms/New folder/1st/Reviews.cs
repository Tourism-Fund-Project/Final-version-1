﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
           
        }
        //replace connections string
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

        private void Reviews_Load(object sender, EventArgs e)
        {
            LoadTheme();
            loadCombobox();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            
        }

        private void loadCombobox()
        {
            try {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    MessageBox.Show("Connection succesfull");
                    // SQL query to fetch the data
                    string query = "SELECT TouristAttraction_ID, Name FROM TouristAttraction";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the ComboBox DataSource
                        comboBoxAttractions.DataSource = dataTable;
                        comboBoxAttractions.DisplayMember = "Name";  
                        comboBoxAttractions.ValueMember = "TouristAttraction_ID";   
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error");
            }
           
        }

        private void loadDGV()
        {

            if (comboBoxAttractions.SelectedValue != null)
            {
                int selectedAttractionID = (int)comboBoxAttractions.SelectedValue;
                string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    DataSet ds;
                    //string query = @"SELECT Number_of_Tourists, Date, Performance_Rank FROM Reviews WHERE AttractionID = @TouristAttraction_ID";
                    string query = @"SELECT Number_of_Tourists, Date, Performance_Rank FROM Reviews WHERE TouristAttraction_ID = @TouristAttraction_ID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@TouristAttraction_ID", selectedAttractionID);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.SelectCommand = command;
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewReviews.DataSource = dataTable;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a tourist attraction.");
            }

            //Adjust the DataGridView columns to fit the data
            dataGridViewReviews.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            loadDGV();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Get the selected tourist attraction ID from the ComboBox
            int selectedAttractionID = (int)comboBoxAttractions.SelectedValue;

            // Get the number of tourists from the TextBox
            int numberOfTourists = int.Parse(txt_numOfTourists.Text);

            // Get the performance rank from the TrackBar
            int performanceRank = trackBar_rank.Value;

            // Get the date from the DateTimePicker
            DateTime reviewDate = dateTimePicker1.Value;

            // Connection string to your database
            string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"INSERT INTO Reviews (AttractionDevelopment_ID, Number_of_Tourists, Performance_Rank, Date)
                         VALUES (@TouristAttraction_ID, @Number_of_Tourists, @Performance_Rank, @Date)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TouristAttraction_ID", selectedAttractionID);
                    command.Parameters.AddWithValue("@Number_of_Tourists", numberOfTourists);
                    command.Parameters.AddWithValue("@Performance_Rank", performanceRank);
                    command.Parameters.AddWithValue("@Date", reviewDate);

                    int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Review added successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Failed to add review.");
                    }
                }
            }
            loadDGV();
        }
    }
}
