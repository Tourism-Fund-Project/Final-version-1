﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SQL
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Needs : Form
    {
        public Needs()
        {
            InitializeComponent();
            dataGridViewNeeds.CellClick += dataGridViewNeeds_CellContentClick;

        }
        private string conString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";

        private void PopulateComboBox()
        {
            //string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            //cbx_provinceAdd.Items.AddRange(provinces);

            string[] categoryRating = { "Optional Maintenance", "Regualur Maintenance", "Low Priority", "Medium Priority", "High Priority", "Urgent Priority" };
            cbxCategoryNeeds.Items.AddRange(categoryRating);
            cbx_FilterNeeds.Items.AddRange(categoryRating);
        }
        private void ClearTexts()
        {
            // Clear all text boxes
            txtAttractionSupervisorFName.Clear();
            txtAttractionSupervisorLName.Clear();
            txtName.Clear();
            txtDescr.Clear();
            txtAccessFundsID.Clear();

          
            //cbxCategoryNeeds.SelectedIndex = -1; 

            
        }


        private void SearchNeedsByCategory(string category)
        {
            using (SqlConnection conn = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("SearchNeedsByCategory", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Category", category);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewNeeds.DataSource = dt;
                }
            }
        }


        private void LoadNeedsDB()
        {
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("DisplayNeeds", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();

                try
                {
                    adapter.Fill(dataTable);
                    dataGridViewNeeds.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred while loading data: {ex.Message}");

                }
            }
        }
        private void UpdateSelectedNeed1()
        {
            if (dataGridViewNeeds.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewNeeds.SelectedRows[0];
                int repairsID;

                if (int.TryParse(selectedRow.Cells["Repairs_ID"].Value.ToString(), out repairsID))
                {
                    using (SqlConnection connection = new SqlConnection(conString))
                    {
                        SqlCommand cmd = new SqlCommand("UpdateNeed1", connection);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@RepairsID", repairsID);
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescr.Text);
                        cmd.Parameters.AddWithValue("@CategoryNeedsName", (cbxCategoryNeeds.SelectedItem?.ToString()));
                        cmd.Parameters.AddWithValue("@AccessFundsFee", decimal.Parse(txtAccessFundsID.Text));
                        string supervisorFullName = $"{txtAttractionSupervisorFName.Text} {txtAttractionSupervisorLName.Text}";
                        cmd.Parameters.AddWithValue("@AttractionSupervisorFullName", (supervisorFullName));

                        try
                        {
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Record updated successfully!");

                            // Refresh the DataGridView after updating
                            LoadNeedsDB();
                            ClearTexts();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Repairs_ID. Please select a valid row.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        private void DeletefromNeedsDB()
        {
            if (dataGridViewNeeds.SelectedRows.Count > 0)
            {
                // Retrieve the selected row from the DataGridView
                DataGridViewRow selectedRow = dataGridViewNeeds.SelectedRows[0];

                // Attempt to parse the Repairs_ID from the selected row
                if (int.TryParse(selectedRow.Cells["Repairs_ID"].Value.ToString(), out int repairsID))
                {
                    using (SqlConnection connection = new SqlConnection(conString))
                    {
                        string query = "DELETE FROM Needs WHERE Repairs_ID = @RepairsID";

                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@RepairsID", repairsID);

                        try
                        {
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Record deleted successfully!");

                            // Refresh the DataGridView after deletion
                            LoadNeedsDB();
                            ClearTexts();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Repairs_ID. Please select a valid row.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private int GetCategoryIdByName(string categoryName)
        {
            int categoryId = 0;
            string query = "SELECT CategoryNeeds_ID FROM dbo.Category_Needs WHERE Name = @Category";

            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@Category", categoryName);
                connection.Open();

                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    categoryId = Convert.ToInt32(result);
                }
            }

            return categoryId;
        }
        private void UpdateSelectedNeed()
        {
            if (dataGridViewNeeds.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewNeeds.SelectedRows[0];
                int repairsID;

                if (int.TryParse(selectedRow.Cells["Repairs_ID"].Value.ToString(), out repairsID))
                {
                    string categoryName = cbxCategoryNeeds.SelectedItem?.ToString();
                    int categoryId = GetCategoryIdByName(categoryName);

                    using (SqlConnection connection = new SqlConnection(conString))
                    {
                        SqlCommand cmd = new SqlCommand("UpdateNeed1", connection);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@RepairsID", repairsID);
                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
                        cmd.Parameters.AddWithValue("@Description", txtDescr.Text);
                        cmd.Parameters.AddWithValue("@Category", categoryId); // Use CategoryNeedsID instead of CategoryNeedsName
                        cmd.Parameters.AddWithValue("@RepairsFee", decimal.Parse(txtAccessFundsID.Text));
                        string supervisorFullName = $"{txtAttractionSupervisorFName.Text} {txtAttractionSupervisorLName.Text}";
                        cmd.Parameters.AddWithValue("@AttractionSupervisorFullName", supervisorFullName);

                        try
                        {
                            connection.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Record updated successfully!");

                            LoadNeedsDB();
                            ClearTexts();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Repairs_ID. Please select a valid row.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }


        private void AddToNeedsDB()
        {
            string categoryName = cbxCategoryNeeds.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(txtName.Text) ||
                string.IsNullOrEmpty(txtDescr.Text) ||
                string.IsNullOrEmpty(categoryName) ||
                !decimal.TryParse(txtAccessFundsID.Text, out decimal accessFundsFee) ||
                accessFundsFee <= 0 ||
                string.IsNullOrEmpty(txtAttractionSupervisorFName.Text) ||
                string.IsNullOrEmpty(txtAttractionSupervisorLName.Text))
            {
                MessageBox.Show("Please ensure all fields are filled in correctly.");
                return;
            }

            int categoryId = GetCategoryIdByName(categoryName);
            if (categoryId == 0)
            {
                MessageBox.Show("Invalid category selected.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("AddNeed1", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@Description", txtDescr.Text);
                cmd.Parameters.AddWithValue("@Category", categoryName);
                cmd.Parameters.AddWithValue("@RepairsFee", accessFundsFee); // Use accessFundsFee directly
                cmd.Parameters.AddWithValue("@AttractionSupervisorFullName", $"{txtAttractionSupervisorFName.Text} {txtAttractionSupervisorLName.Text}");

                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record added successfully!");
                    LoadNeedsDB();
                    ClearTexts();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }
            }
        }


        private void AddToNeedsDB1()
        {
            // Assuming you have ComboBoxes or TextBoxes to select the associated values
            string categoryName = cbxCategoryNeeds.SelectedItem?.ToString();
            decimal accessFundsFee = decimal.Parse(txtAccessFundsID.Text);
            string supervisorFullName = $"{txtAttractionSupervisorFName.Text} {txtAttractionSupervisorLName.Text}";
            
            if (!string.IsNullOrEmpty(txtName.Text) && !string.IsNullOrEmpty(txtDescr.Text) && !string.IsNullOrEmpty(categoryName) && accessFundsFee > 0 && !string.IsNullOrEmpty(supervisorFullName))
            {
                int categoryId = GetCategoryIdByName(categoryName);


                using (SqlConnection connection = new SqlConnection(conString))
                {
                    SqlCommand cmd = new SqlCommand("AddNeed1", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", txtName.Text);
                    cmd.Parameters.AddWithValue("@Description", txtDescr.Text);
                    cmd.Parameters.AddWithValue("@CategoryNeedsName", categoryName);
                    cmd.Parameters.AddWithValue("@AccessFundsFee", accessFundsFee);
                    cmd.Parameters.AddWithValue("@AttractionSupervisorFullName", supervisorFullName);

                    try
                    {
                        connection.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record added successfully!");

                        // Refresh the DataGridView after adding a new record
                        LoadNeedsDB();
                        ClearTexts();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"An error occurred: {ex.Message}");
                    }
                }
            }
        }

        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }

        private void Needs_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            LoadNeedsDB();
            //PopulateCategoryCBX();
            PopulateComboBox();


        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddToNeedsDB();
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateSelectedNeed();
            
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            DeletefromNeedsDB();
            
        }

       

        private void SearchNeedsByName(string searchName)
        {
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand cmd = new SqlCommand("SearchNeedsByName", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameter
                cmd.Parameters.AddWithValue("@SearchName", string.IsNullOrWhiteSpace(searchName) ? (object)DBNull.Value : searchName);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                connection.Open();
                adapter.Fill(dt);
                connection.Close();

                // Bind the results to your DataGridView
                dataGridViewNeeds.DataSource = dt;
            }
        }

        private void btn_Filter_Needs_Click(object sender, EventArgs e)
        {
            string searchName = txt_FilterName.Text;
            SearchNeedsByName(searchName);


            string selectedCategory = cbx_FilterNeeds.SelectedItem.ToString();
            SearchNeedsByCategory(selectedCategory);

            txt_FilterName.Clear();
            cbx_FilterNeeds.SelectedIndex = -1;

        }

        private void dataGridViewNeeds_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewNeeds.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewNeeds.SelectedRows[0];

                // Get the selected row and set the text boxes
                txtName.Text = selectedRow.Cells["Name"].Value.ToString();
                txtDescr.Text = selectedRow.Cells["Description"].Value.ToString();
                txtAccessFundsID.Text = selectedRow.Cells["Repairs Fee"].Value.ToString();

                // Split the full name into first name and last name
                string fullName = selectedRow.Cells["Attraction Supervisor Full Name"].Value.ToString();
                string[] nameParts = fullName.Split(' ');

                if (nameParts.Length >= 2)
                {
                    txtAttractionSupervisorFName.Text = nameParts[0]; // First Name
                    txtAttractionSupervisorLName.Text = nameParts[1]; // Last Name
                }
                else if (nameParts.Length == 1)
                {
                    txtAttractionSupervisorFName.Text = nameParts[0]; // Only First Name exists
                    txtAttractionSupervisorLName.Text = string.Empty; // Clear Last Name field
                }
                else
                {
                    txtAttractionSupervisorFName.Text = string.Empty;
                    txtAttractionSupervisorLName.Text = string.Empty;
                }

                // Set the ComboBox value
                string categoryName = selectedRow.Cells["Category"].Value.ToString();
                if (cbxCategoryNeeds.Items.Contains(categoryName))
                {
                    cbxCategoryNeeds.SelectedItem = categoryName;
                }
            }
        }

        private void cbxCategoryNeeds_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Catefogory2maintain = cbxCategoryNeeds.SelectedItem.ToString();
        }

        private void cbx_FilterNeeds_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string selectedCategory = cbx_FilterNeeds.SelectedItem.ToString();
            //SearchNeedsByCategory(selectedCategory);
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            LoadNeedsDB();
            txt_FilterName.Clear();
            cbx_FilterNeeds.SelectedIndex = -1;

            ClearTexts();

        }
    }
}
