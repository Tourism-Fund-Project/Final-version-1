﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Tourism_Fund_Distribution_final.Forms;

namespace Tourism_Fund_Distribution_final
{
    public partial class AddReviews : Form
    {
        private Reviews mainForm;
        public AddReviews(Reviews form)
        {
            InitializeComponent();
            mainForm = form;
        }

        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";


        private void AddReview()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddReviews", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", txt_AttractionName.Text);
                cmd.Parameters.AddWithValue("@NumberOfTourists", txt_NumTourists.Text);
                cmd.Parameters.AddWithValue("@PerformanceRank", int.Parse(txt_PerformanceRank.Text));
                cmd.Parameters.AddWithValue("@AttractionDevelopment", txt_AttractionDev.Text);
                cmd.Parameters.AddWithValue("@AttractionSupervisor_FName", txt_AttractionSupervisor_FName.Text);
                cmd.Parameters.AddWithValue("@AttractionSupervisor_SName", txt_AttractionSupervisor_SName.Text);
                cmd.Parameters.AddWithValue("@ReviewDate", dateTimePickerReviewDate.Value);
                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Tourist attraction Review added successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        
        private void btn_SubmitReview_Click(object sender, EventArgs e)
        {
            AddReview();
            mainForm.ReloadReviewsDataGrid();
            this.Close();

        }

        private void AddReviews_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
        }
        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }
    }
}
