﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Budget : Form
    {
        
        public Budget()
        {
            InitializeComponent();


        }

        private void Budget_Load(object sender, EventArgs e)
        {
            LoadTheme();

        }
        
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            lblAvailableAmount.ForeColor = ThemeColour.PrimaryColor;
            lblExcessAmount.ForeColor = ThemeColour.PrimaryColor;
            lblTotalBudget.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
            label5.ForeColor = ThemeColour.PrimaryColor;
            label6.ForeColor = ThemeColour.PrimaryColor;
            label7.ForeColor = ThemeColour.PrimaryColor;
            label8.ForeColor = ThemeColour.PrimaryColor;
            label9.ForeColor = ThemeColour.PrimaryColor;
            label10.ForeColor = ThemeColour.PrimaryColor;
            label11.ForeColor = ThemeColour.PrimaryColor;
            //label4.ForeColor = ThemeColour.PrimaryColor;
        }
    }    
}

