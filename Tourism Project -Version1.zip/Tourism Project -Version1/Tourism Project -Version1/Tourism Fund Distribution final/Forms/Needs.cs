﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SQL
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Needs : Form
    {
        public Needs()
        {
            InitializeComponent();
        }

        private void LoadTheme()
        {
            //UI code for colors 
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btns.BackColor = ThemeColour.PrimaryColor;
                    btns.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
            label5.ForeColor = ThemeColour.PrimaryColor;
            label6.ForeColor = ThemeColour.PrimaryColor;
            label7.ForeColor = ThemeColour.PrimaryColor;
            label8.ForeColor = ThemeColour.PrimaryColor;
        }

        private void Needs_Load(object sender, EventArgs e)
        {
            LoadTheme();
            
        }

        
    }
}
