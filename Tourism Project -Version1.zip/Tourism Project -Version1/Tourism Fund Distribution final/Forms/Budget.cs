﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Budget : Form
    {
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";
        private decimal currentOperatingCosts = 0m;
        public Budget()
        {
            InitializeComponent();
            

        }

        private void Budget_Load(object sender, EventArgs e)
        {
            LoadTheme();
            
            
            LoadCurrentOperatingCosts();
            UpdateBudgetLabels();
            PopulateComboBox();
        }
        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            comboBox1.Items.AddRange(provinces);
            cmbAddRegion.Items.AddRange(provinces);
            cmbSubtractRegion.Items.AddRange(provinces);
        }
        private void LoadCurrentOperatingCosts()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT SUM(Operating_Costs) AS TotalOperatingCosts FROM dbo.Budget";
                    SqlCommand command = new SqlCommand(query, con);
                    object result = command.ExecuteScalar();
                    currentOperatingCosts = result != DBNull.Value ? Convert.ToDecimal(result) : 0;
                    lblAvailableAmount.Text = $"Operating Costs: R{currentOperatingCosts:N2}";
                    lblExcessAmount.Text = "Excess Amount: R0.00"; // Initially no excess
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void ClearTextBoxes()
        {
            txtLease.Clear();
            txtOperatng.Clear();
            cmbSubtractRegion.SelectedIndex = -1;
            //comboBox1.SelectedIndex = -1;
            cmbAddRegion.SelectedIndex = -1;
            //dateTimePicker1.Value = DateTime.Now;
        }


        private void UpdateBudgetLabels()
        {
            decimal totalBudget = 1200000000m; // Example total budget: R1.2 billion
            lblTotalBudget.Text = $"Total Budget: R{totalBudget:N2}";

            decimal excessAmount = totalBudget - currentOperatingCosts;
            if (excessAmount < 0)
            {
                lblExcessAmount.Text = $"Excess Amount: R{Math.Abs(excessAmount):N2}";
                lblExcessAmount.ForeColor = Color.Red;
            }
            else
            {
                lblExcessAmount.Text = $"Excess Amount: R{excessAmount:N2}";
                lblExcessAmount.ForeColor = Color.Black;
            }
        }

        private void ShowFilteredBudget(string provnince)
        {
            
            string query = $"SELECT * FROM Budget WHERE Regions LIKE '{provnince}%'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dgvBudget.DataSource = dataTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            lbl_lease.ForeColor = ThemeColour.PrimaryColor;
            lbl_operating.ForeColor = ThemeColour.PrimaryColor;
            //label4.ForeColor = ThemeColour.PrimaryColor;
        }
        private void LoadBudgetDB()
        {
            string query = "SELECT * FROM dbo.Budget";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dgvBudget.DataSource = dataTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {

            LoadBudgetDB();
            ClearTextBoxes();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string addRegion = cmbAddRegion.SelectedItem.ToString();
            decimal amountToAdd;

            if (decimal.TryParse(txtOperatng.Text, out amountToAdd) && amountToAdd > 0)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();
                    try
                    {
                        // Update the region to add operating costs
                        SqlCommand cmdAdd = new SqlCommand("UPDATE Budget SET Operating_Costs = Operating_Costs + @Amount WHERE Regions = @Region", conn, transaction);
                        cmdAdd.Parameters.AddWithValue("@Amount", amountToAdd);
                        cmdAdd.Parameters.AddWithValue("@Region", addRegion);
                        cmdAdd.ExecuteNonQuery();

                        transaction.Commit();

                        MessageBox.Show("Operating costs ADDED successfully.");
                        
                       
                        ClearTextBoxes();
                        
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"An error occurred: {ex.Message}");
                    }
                    LoadBudgetDB();
                    LoadCurrentOperatingCosts();
                    UpdateBudgetLabels();
                }
            }
            else
            {
                MessageBox.Show("Invalid amount. Please enter a positive value.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string selectedRegion = comboBox1.SelectedItem.ToString();
            decimal newLease;
            DateTime newDate = dateTimePicker1.Value;

            // Check if the Lease amount is a valid decimal number
            if (decimal.TryParse(txtLease.Text, out newLease))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();
                    try
                    {
                        // Update the Lease and Date columns for the selected region
                        SqlCommand cmdUpdate = new SqlCommand("UPDATE Budget SET Lease = @NewLease, Date = @NewDate WHERE Regions = @Region", conn, transaction);
                        cmdUpdate.Parameters.AddWithValue("@NewLease", newLease);
                        cmdUpdate.Parameters.AddWithValue("@NewDate", newDate);
                        cmdUpdate.Parameters.AddWithValue("@Region", selectedRegion);
                        cmdUpdate.ExecuteNonQuery();

                        transaction.Commit();
                        MessageBox.Show("Lease and Date updated successfully.");
                        
                        dateTimePicker1.Value = DateTime.Now;
                        ClearTextBoxes();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"An error occurred: {ex.Message}");
                    }
                }

                // Refresh DataGridView
                LoadBudgetDB();
                
            }
            else
            {
                MessageBox.Show("Please enter a valid number for Lease.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string subtractRegion = cmbSubtractRegion.SelectedItem.ToString(); // Selected region to subtract from
            decimal amountToRemove;

            if (decimal.TryParse(txtOperatng.Text, out amountToRemove) && amountToRemove > 0)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();
                    try
                    {
                        // Fetch the current Operating_Costs for the selected region
                        SqlCommand cmdGetCosts = new SqlCommand("SELECT Operating_Costs FROM Budget WHERE Regions = @Region", conn, transaction);
                        cmdGetCosts.Parameters.AddWithValue("@Region", subtractRegion);
                        decimal currentOperatingCosts = (decimal)cmdGetCosts.ExecuteScalar();

                        // Check if the subtraction operation is valid (cannot go negative)
                        if (currentOperatingCosts < amountToRemove)
                        {
                            throw new Exception("Insufficient budget in the selected region to subtract.");
                        }

                        // Update the operating costs for the selected region
                        SqlCommand cmdUpdate = new SqlCommand("UPDATE Budget SET Operating_Costs = Operating_Costs - @Amount WHERE Regions = @Region", conn, transaction);
                        cmdUpdate.Parameters.AddWithValue("@Amount", amountToRemove);
                        cmdUpdate.Parameters.AddWithValue("@Region", subtractRegion);
                        cmdUpdate.ExecuteNonQuery();

                        transaction.Commit();

                        MessageBox.Show("Operating costs removed successfully.");
                        LoadBudgetDB();
                        LoadCurrentOperatingCosts();
                        UpdateBudgetLabels();
                        ClearTextBoxes();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"An error occurred: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid amount. Please enter a positive value.");
            }
            
           
        }

        
       


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if an item is selected
            if (comboBox1.SelectedItem != null)
            {
                string selectedProvince = comboBox1.SelectedItem.ToString();
                if (!string.IsNullOrEmpty(selectedProvince))
                {
                    // Proceed to filter regions by the selected province
                    ShowFilteredBudget(selectedProvince);
                }
                else
                {
                    MessageBox.Show("Selected province is empty.");
                }
            }
            else
            {
                // Handle the case where no item is selected (optional)
                MessageBox.Show("Please select a province.");
            }
        }

        private void cmbSubtractRegion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbAddRegion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_request_Click(object sender, EventArgs e)
        {
            decimal totalBudget = 1200000000m; // Example total budget: R1.2 billion
            decimal excessAmount = totalBudget - currentOperatingCosts;

            if (excessAmount < 0)
            {
                MessageBox.Show("The changes exceed the total budget. Please adjust the amounts.");
            }
            else
            {
                MessageBox.Show("Budget changes accepted.");
                // You can perform additional actions here if needed
            }
            //AccessFunds accessFundsForm = new AccessFunds();
            //accessFundsForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //groupBox1.Visible = true;
            // Point newlblLocation1 = new Point(72, 383);
            //Point newtxtLocation1 = new Point(61, 421);
            //lbl_operating.Location = newlblLocation1;
            //txtOperatng.Location = newtxtLocation1;
            txtOperatng.Visible = true;
            lbl_operating.Visible = true;
            lbl_forAddCbx.Visible = true;
            cmbAddRegion.Visible = true;
            btnAdd.Visible = true;
            
            //keep these off
            cmbSubtractRegion.Visible = false;
            lbl_lease.Visible = false;
            txtLease.Visible = false;
            dateTimePicker1.Visible = false;
            btnUpdate.Visible = false;
            monthCalendar1.Visible = false;
            btnDelete.Visible = false;
            lblForDelCBX.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //groupBox1.Visible = true;
            //Point newlblLocation = new Point(357, 383);
            // Point newtxtLocation = new Point(346, 421);
            //lbl_operating.Location = newlblLocation;
            //txtOperatng.Location = newtxtLocation;
            cmbSubtractRegion.Visible = true;
            lblForDelCBX.Visible = true; 
            txtOperatng.Visible = true;
            btnDelete.Visible = true;
            lbl_operating.Visible = true;

            //saty off
            cmbAddRegion.Visible = false;
            btnAdd.Visible = false;
            groupBox1.Visible = false;
            lbl_lease.Visible = false;
            txtLease.Visible = false;
            dateTimePicker1.Visible = false;
            btnUpdate.Visible = false;
            monthCalendar1.Visible = false;
            lbl_forAddCbx.Visible = false;
        }

        private void UIforBudget(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //groupBox1.Visible = true;
            lbl_lease.Visible = true;
            txtLease.Visible = true;
            dateTimePicker1.Visible = true;
            btnUpdate.Visible = true;
            monthCalendar1.Visible = true;

            //
            lblForDelCBX.Visible = false;
            txtOperatng.Visible = false;
            btnDelete.Visible = false;
            btnAdd.Visible = false;
            cmbAddRegion.Visible = false;
            cmbSubtractRegion.Visible = true;
            lbl_forAddCbx.Visible = false;
            lbl_operating.Visible = false;
            cmbSubtractRegion.Visible = false;
        }
    }

    // Class for ComboBox items with text and value properties
    public class ComboBoxItem
    {
        public string Text { get; set; }
        public int Value { get; set; }

        public override string ToString() => Text;
    }
}

