﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;
using LiveCharts;
using LiveCharts.Definitions.Charts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;
using Tourism_Fund_Distribution_final.Forms.Report_Charts;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reports : Form
    {
        public Reports()
        {
            InitializeComponent();
            
            
        }
        

        private void Reports_Load(object sender, EventArgs e)
        {
            string constStr = @"Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataAdapter adp;
            DataSet ds;
            SqlDataReader reader;
        }

        private void DisplayData(string query)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    // Open the connection
                    conn.Open();

                    // Create a SqlDataAdapter to execute the query and fill the results into a DataTable
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);

                    // Create a DataTable to hold the query results
                    DataTable dt = new DataTable();

                    // Fill the DataTable with the results of the query
                    sda.Fill(dt);

                    // Bind the DataTable to the DataGridView to display the results
                    dataGridView1.DataSource = dt;
                }
            }
            catch (SqlException ex)
            {
                // Handle SQL-related exceptions
                MessageBox.Show($"SQL Error: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Handle other types of exceptions
                MessageBox.Show($"Error: {ex.Message}", "General Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Clear the DataGridView by setting its DataSource to null or an empty DataTable
            dataGridView1.DataSource = null;

            // Optionally, clear the DataTable if you're managing it separately
            DataTable dt = new DataTable();
            dt.Clear();
        }

       

        private void btnViewGraph_Click_1(object sender, EventArgs e)
        {
            LineChart_Report ln = new LineChart_Report();
            ln.ShowDialog();

        }

        private void btnTopRanked_Click(object sender, EventArgs e)
        {
            string query = @"
                SELECT 
                ta.Region_ID, 
                r.Name AS [Region Name], 
                ta.Name AS [Attraction Name], 
                ta.Description, 
                rev.Performance_Rank,
                rev.Number_Of_Tourists
                FROM 
                TouristAttraction ta
                JOIN 
                Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
                JOIN 
                Regions r ON ta.Region_ID = r.Region_ID
                ORDER BY 
                rev.Performance_Rank DESC, 
                rev.Number_Of_Tourists DESC
                OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;
                        ";
            
            DisplayData(query);
            /*
            string query = @"
        SELECT 
            ta.Region_ID, 
            r.Name AS [Region Name], 
            ta.Name AS [Attraction Name], 
            ta.Description, 
            rev.Performance_Rank 
        FROM 
            TouristAttraction ta
        JOIN 
            Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
        JOIN 
            Regions r ON ta.Region_ID = r.Region_ID
        ORDER BY 
            rev.Performance_Rank ASC
        OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY; ";

            DisplayData(query);*/
        }

        private void btnTopTourists_Click_1(object sender, EventArgs e)
        {
            string query = @"
    SELECT 
        ta.Region_ID, 
        r.Name AS [Region Name], 
        ta.Name AS [Attraction Name], 
        ta.Description, 
        rev.Number_of_Tourists, 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    JOIN 
        Regions r ON ta.Region_ID = r.Region_ID
    ORDER BY 
        rev.Number_of_Tourists DESC
    OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;
    ";

            DisplayData(query);
        }

        private void btnTopPerRegion_Click_1(object sender, EventArgs e)
        {
            string query = @"
    SELECT 
        ta.Region_ID, 
        r.Name AS [Region Name], 
        ta.Name AS [Attraction Name], 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    JOIN 
        Regions r ON ta.Region_ID = r.Region_ID
    WHERE 
        rev.Performance_Rank = (
            SELECT MIN(rev2.Performance_Rank)
            FROM Reviews rev2
            WHERE rev2.TouristAttraction_ID = rev.TouristAttraction_ID
        )
    ORDER BY 
        rev.Performance_Rank DESC;
    ";

            DisplayData(query);
        }

        private void btnViewPieChart_Click(object sender, EventArgs e)
        {
            PieChart_Report pn = new PieChart_Report();
            pn.ShowDialog();
        }

    }
}
