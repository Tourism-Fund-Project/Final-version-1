﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Needs : Form
    {
        public Needs()
        {
            InitializeComponent();
        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btns.BackColor = ThemeColour.PrimaryColor;
                    btns.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
        }

        private void Needs_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }
    }
}
