﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
            cbxRegions1.SelectedIndexChanged += cbxRegions1_SelectedIndexChanged;
 
        }


        //replace connections here or in each method
        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

        private void Reviews_Load(object sender, EventArgs e)
        {
            LoadTheme();
            //displayTouristAttractions();
            //loadCBXRegions();
            PopulateComboBox();
        }


        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
           
        }
        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cbxRegions1.Items.AddRange(provinces);
        }


        private void FilterRegionsByProvince(string province)
        {
            string query = $"SELECT * FROM TouristAttraction WHERE Region LIKE '{province}%'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridViewTA.DataSource = dataTable; // Bind the filtered data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private void ReviewsByProvince(string province)
        {
            // First, get the TouristAttraction_IDs for the selected province
            string query4TA = $"SELECT TouristAttraction_ID FROM TouristAttraction WHERE Region LIKE '{province}%'";
            string queryReviews = $@"SELECT * FROM Reviews WHERE TouristAttraction_ID IN ({query4TA})";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Get Tourist Attraction IDs
                    SqlCommand command4TA = new SqlCommand(query4TA, connection);
                    SqlDataAdapter dataAdapterTA = new SqlDataAdapter(command4TA);
                    DataTable dataTableTA = new DataTable();
                    dataAdapterTA.Fill(dataTableTA);

                    // Build the query for Reviews
                    SqlCommand commandReviews = new SqlCommand(queryReviews, connection);
                    SqlDataAdapter dataAdapterReviews = new SqlDataAdapter(commandReviews);
                    DataTable dataTableReviews = new DataTable();
                    dataAdapterReviews.Fill(dataTableReviews);

                    dataGridViewReviews.DataSource = dataTableReviews; // Bind the filtered reviews data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        //not in use
        private void loadCBXRegions()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT Region_ID, Name FROM Regions";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataReader reader = command.ExecuteReader();
                        DataTable dt = new DataTable();
                        dt.Load(reader);

                        cbxRegions1.DisplayMember = "Name";
                        cbxRegions1.ValueMember = "Region_ID";
                        cbxRegions1.DataSource = dt;
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

      //not in  use 
        private void displayTouristAttractions()
        {
            

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM dbo.TouristAttraction";  
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewTA.DataSource = dataTable; 
                }
                connection.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string selectedProvince = cbxRegions1.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedProvince))
            {
                
                FilterRegionsByProvince(selectedProvince);

                
                ReviewsByProvince(selectedProvince);
            }
            else
            {
                MessageBox.Show("Please select a province.");
            }

            //LoadReviews();
        }


        //not in use
        private void LoadReviews()
        {
            
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM dbo.Reviews";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        //command.Parameters.AddWithValue("@Region", region);

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewReviews.DataSource = dataTable;
                    }
                    connection.Close();
                }
            MessageBox.Show("Reviews added");
            
           
        }


        private void cbxRegions1_SelectedIndexChanged(object sender, EventArgs e)
        {

            // Check if SelectedItem is not null before calling ToString()
            if (cbxRegions1.SelectedItem != null)
            {
                string selectedProvince = cbxRegions1.SelectedItem.ToString();
                if (!string.IsNullOrEmpty(selectedProvince))
                {
                    // Proceed to filter regions by the selected province
                    FilterRegionsByProvince(selectedProvince);
                }
                else
                {
                    MessageBox.Show("Selected province is empty.");
                }
            }
            else
            {
                MessageBox.Show("No province selected.");
            }
        }
    }
}
