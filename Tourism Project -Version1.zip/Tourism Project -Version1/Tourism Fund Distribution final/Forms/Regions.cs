﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Regions : Form
    {
        public Regions()
        {
            InitializeComponent();
            LoadTheme();
            //LoadComboBox();
            PopulateComboBox();
            cmb_region.SelectedIndexChanged += new EventHandler(cmb_region_SelectedIndexChanged);


        }

        private string connectionString = "Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True";

        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btns.BackColor = ThemeColour.PrimaryColor;
                    btns.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
        }
        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cmb_region.Items.AddRange(provinces);
        }

        private void LoadRegionsDB()
        {
            string query = "SELECT * FROM dbo.Regions";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridViewRegion.DataSource = dataTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private void FilterRegionsByProvince(string province)
        {
            string query = $"SELECT * FROM Regions WHERE Name LIKE '{province}%'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                   
                    SqlCommand command = new SqlCommand(query, connection);
                   
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridViewRegion.DataSource = dataTable; // Bind the filtered data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
       



        private void DeleteRegion(int Region_ID)
        {

            string query = "DELETE FROM Regions WHERE Region_ID = @Region_ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Region_ID", Region_ID);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record deleted successfully.");
                        
                    }
                    else
                    {
                        MessageBox.Show("No record found with the ID you specified");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

        }
        private void addInDB()
        {
            string NameRegion = txt_regionName.Text;
            int ZipCode;
            //int Budget_ID= 0;

            //NameRegion = txt_regionName.Text;
            ZipCode = int.Parse(txt_regionZip.Text);

            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                SqlCommand InsertInDB = new SqlCommand("INSERT INTO Regions ( Name, Zip_Code) VALUES(@NameRegion, @ZipCode) ", connection);
                InsertInDB.Parameters.AddWithValue("@NameRegion", NameRegion);
                InsertInDB.Parameters.AddWithValue("@ZipCode", ZipCode);
                //InsertInDB.Parameters.AddWithValue("@Budget_ID", Budget_ID);


                InsertInDB.ExecuteNonQuery();

                MessageBox.Show("Region added successfully.");
                LoadRegionsDB();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void updateInDB()
        {
            // Check if ComboBox selections are not null
            //if (cmb_region.SelectedItem == null)
            //{
             //   MessageBox.Show("Please select a valid region.");
             //   return;
            //}

            // Ensure text boxes are not empty
            string NameRegion = txt_regionName.Text.Trim();
            string ZipCode = txt_regionZip.Text.Trim();

            if (string.IsNullOrWhiteSpace(NameRegion) || string.IsNullOrWhiteSpace(ZipCode) || ZipCode.Length != 4)
            {
                MessageBox.Show("Please ensure all fields are correctly filled out and Zip Code is exactly 4 characters.");
                return;
            }

            // Ensure a row is selected in the DataGridView
            if (dataGridViewRegion.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedAttraction = dataGridViewRegion.SelectedRows[0];
                int RegionIDClick = Convert.ToInt32(selectedAttraction.Cells["Region_ID"].Value);

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE Regions SET Name = @NameRegion, Zip_Code = @ZipCode WHERE Region_ID = @RegionID";
                        SqlCommand updateCommand = new SqlCommand(query, connection);

                        updateCommand.Parameters.Add("@NameRegion", SqlDbType.NVarChar).Value = NameRegion;
                        updateCommand.Parameters.Add("@ZipCode", SqlDbType.Char).Value = ZipCode; // Adjusted for CHAR(4)
                        updateCommand.Parameters.Add("@RegionID", SqlDbType.Int).Value = RegionIDClick;

                        int rowsAffected = updateCommand.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Region updated successfully.");
                            LoadRegionsDB();
                        }
                        else
                        {
                            MessageBox.Show("No region found with the specified ID.");
                        }

                        connection.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a row from the DataGridView.");
            }
        }

        private void updateInDB1()
        {
            
            string NameRegion = txt_regionName.Text.Trim();
            string ZipCode = txt_regionZip.Text.Trim();
            //int RegionID;
           
            // Validate input for ZipCode
            // Validate input for ZipCode
            if (string.IsNullOrWhiteSpace(NameRegion) || string.IsNullOrWhiteSpace(ZipCode) || ZipCode.Length != 4)
            {
                MessageBox.Show("Please ensure all fields are correctly filled out and Zip Code is exactly 4 characters.");
                return;
            }

            DataGridViewRow selectedAttraction = dataGridViewRegion.SelectedRows[0];
            int RegionIDClick = Convert.ToInt32(selectedAttraction.Cells["Region_ID"].Value);

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE Regions SET Name = @NameRegion, Zip_Code = @ZipCode WHERE Region_ID = @RegionID";
                    SqlCommand updateCommand = new SqlCommand(query, connection);

                    updateCommand.Parameters.Add("@NameRegion", SqlDbType.NVarChar).Value = NameRegion;
                    updateCommand.Parameters.Add("@ZipCode", SqlDbType.Char).Value = ZipCode; // Adjusted for CHAR(4)
                    updateCommand.Parameters.Add("@RegionID", SqlDbType.Int).Value = RegionIDClick;

                    //updateCommand.Parameters.AddWithValue("@NameRegion", NameRegion);
                    //updateCommand.Parameters.AddWithValue("@ZipCode", ZipCode);
                    //updateCommand.Parameters.AddWithValue("@RegionID", RegionID); 

                    int rowsAffected = updateCommand.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Region updated successfully.");
                        
                        LoadRegionsDB();
                    }
                    else
                    {
                        MessageBox.Show("No region found with the specified ID.");
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }


        private void Regions_Load(object sender, EventArgs e)
        {

            //LoadRegionsDB();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            LoadRegionsDB();
            MessageBox.Show("Database updated");
        }
        private void ClearTextBoxes()
        {
            txt_regionID.Clear();
            txt_regionName.Clear();
            txt_regionZip.Clear();
            cmb_region.SelectedIndex = -1; // Reset ComboBox selection if needed
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //DeleteRegion();
            if (int.TryParse(txt_regionID.Text, out int regionID))
            {
                DeleteRegion(regionID);
                ClearTextBoxes(); // Clear textboxes after the delete operation
            }
            else
            {
                MessageBox.Show("Please enter a valid Region ID.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            addInDB();
            ClearTextBoxes();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {


            //lblRegionID.Visible = true;
            //txt_regionID.Visible = true;
            //txt_regionID.Focus();
            updateInDB();
            ClearTextBoxes();

            
        }
        private void btnUpdate_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void btnUpdate_MouseLeave(object sender, EventArgs e)
        {
            
        }
        private void dataGridViewRegion_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmb_region_SelectedIndexChanged(object sender, EventArgs e)
        {

            // Check if SelectedItem is not null before calling ToString()
            if (cmb_region.SelectedItem != null)
            {
                string selectedProvince = cmb_region.SelectedItem.ToString();
                if (!string.IsNullOrEmpty(selectedProvince))
                {
                    // Proceed to filter regions by the selected province
                    FilterRegionsByProvince(selectedProvince);
                }
                else
                {
                    MessageBox.Show("Selected province is empty.");
                }
            }
            else
            {
                MessageBox.Show("No province selected.");
            }

        }
    }
}
