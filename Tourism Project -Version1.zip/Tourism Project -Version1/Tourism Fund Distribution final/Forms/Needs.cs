﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SQL
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Needs : Form
    {
        public Needs()
        {
            InitializeComponent();
        }

        //Connect
        //private string conString = @"Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";
        private string conString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";
        private SqlDataAdapter stringDataAdapter;
        private DataSet stringDataSet;
        private SqlDataReader stringDataReader;
        
        private void LoadNeedsDB()
        {
            string query = "SELECT * FROM dbo.Needs ORDER BY CategoryNeeds_ID DESC";

            using (SqlConnection connection = new SqlConnection(conString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        public enum RegionWithSupervisorID
        {
            EasternCape = 3779,
            FreeState = 3772,
            Gauteng = 3773,
            KwaZuluNatal = 3771,
            Limpopo = 3774,
            Mpumalanga = 3775,
            NorthWest = 3777,
            NorthernCape = 3776,
            WesternCape = 3778
        }

        private RegionWithSupervisorID GetAttractionSupervisorID(string province)
        {
            switch (province)
            {
                case "Eastern Cape":
                    return RegionWithSupervisorID.EasternCape;
                case "Free State":
                    return RegionWithSupervisorID.FreeState;
                case "Gauteng":
                    return RegionWithSupervisorID.Gauteng;
                case "KwaZulu-Natal":
                    return RegionWithSupervisorID.KwaZuluNatal;
                case "Limpopo":
                    return RegionWithSupervisorID.Limpopo;
                case "Mpumalanga":
                    return RegionWithSupervisorID.Mpumalanga;
                case "North-West":
                    return RegionWithSupervisorID.NorthWest;
                case "Northern Cape":
                    return RegionWithSupervisorID.NorthernCape;
                case "Western Cape":
                    return RegionWithSupervisorID.WesternCape;
                default:
                    throw new ArgumentException("Invalid Region Supervisor ");
            }
        }
        private void FilterNeedsByProvince(string province)
        {
            try
            {
                RegionWithSupervisorID RegionEnum = GetAttractionSupervisorID(province);
                int SupervisorID = (int)RegionEnum;

                string query = "SELECT * FROM Needs WHERE Attraction_Supervisor_ID = @SupervisorID";

                using (SqlConnection connection = new SqlConnection(conString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupervisorID", SupervisorID);

                        using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            dataAdapter.Fill(dataTable);

                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void PopulateCategoryCBX()
        {
            // Populate Category ComboBox
            using (SqlConnection con = new SqlConnection(conString))
            {
                try
                {
                    con.Open(); // Open the connection

                    string categoryQuery = "SELECT * FROM Category_Needs ";
                    SqlCommand command = new SqlCommand(categoryQuery, con);
                    
                    SqlDataReader reader = command.ExecuteReader();
                    comboBox2.Items.Clear(); // Clear existing items

                    while (reader.Read())
                    {
                        // Concatenate ID and Name to display in the ComboBox
                        string item = $"{reader["CategoryNeeds_ID"]} - {reader["Name"]}";
                        comboBox2.Items.Add(item);
                    }

                    reader.Close(); // Close the reader
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void PopulateComboBox()
        {
            string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            comboBox1.Items.AddRange(provinces);
        }


        private void LoadTheme()
        {
            //UI code for colors 
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btns.BackColor = ThemeColour.PrimaryColor;
                    btns.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
        }

        private void Needs_Load(object sender, EventArgs e)
        {
            LoadTheme();
            //LoadNeedsDB();
            PopulateComboBox();
            PopulateCategoryCBX();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
                try
                {   
                    LoadNeedsDB();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something went wrong: " + ex.Message);
                }
            //}

            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRepair = dataGridView1.SelectedRows[0];
                int RepairsID = Convert.ToInt32(selectedRepair.Cells["Repairs_ID"].Value);

                using (SqlConnection con = new SqlConnection(conString))
                {
                    try
                    {
                        
                        con.Open();
                        string query = "DELETE FROM Needs WHERE Repairs_ID = @RepairIDCLICK";
                        SqlCommand command = new SqlCommand(query, con);
                        command.Parameters.AddWithValue("@RepairIDCLICK", selectedRepair);
                        command.ExecuteNonQuery();

                        // Refresh DataGridView after deletion
                        LoadNeedsDB();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an Repair to delete");
            }
                
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO Needs (Name, Description ) VALUES(@Name, @Description)";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@Name", textBox1.Text);
                    command.Parameters.AddWithValue("@Description", textBox2.Text);
                    command.ExecuteNonQuery();

                    // Refresh DataGridView after adding
                    LoadNeedsDB();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRepair = dataGridView1.SelectedRows[0];
                int RepairsID = Convert.ToInt32(selectedRepair.Cells["Repairs_ID"].Value);
                using (SqlConnection con = new SqlConnection(conString))
                {
                    try
                    {
                        con.Open();

                        string query = "UPDATE Needs SET Name = @Name, Description = @Description, CategoryNeeds_ID = @CategoryNeeds_ID WHERE Repairs_ID = RepairIDCLICK";
                        SqlCommand command = new SqlCommand(query, con);
                        command.Parameters.AddWithValue("@Name", textBox1.Text);
                        command.Parameters.AddWithValue("@Description", textBox2.Text);
                        command.Parameters.AddWithValue("@CategoryNeeds_ID", comboBox2.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@RepairIDCLICK", selectedRepair);
                        command.ExecuteNonQuery();

                        // Refresh DataGridView after updating
                        LoadNeedsDB();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please click on the Repair to update");
            }

           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Get the selected province as a string
            string selectedProvince = comboBox1.SelectedItem.ToString();

            // Call the method to filter needs by the selected province
            FilterNeedsByProvince(selectedProvince);
        }
    }
}
