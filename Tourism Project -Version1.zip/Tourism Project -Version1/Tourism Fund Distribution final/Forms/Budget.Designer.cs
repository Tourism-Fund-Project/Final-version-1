﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Budget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDisplay = new System.Windows.Forms.Button();
            this.dgvBudget = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.lblTotalBudget = new System.Windows.Forms.Label();
            this.lblAvailableAmount = new System.Windows.Forms.Label();
            this.lblExcessAmount = new System.Windows.Forms.Label();
            this.btn_request = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtOperatng = new System.Windows.Forms.TextBox();
            this.lbl_operating = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtLease = new System.Windows.Forms.TextBox();
            this.lblForDelCBX = new System.Windows.Forms.Label();
            this.lbl_lease = new System.Windows.Forms.Label();
            this.cmbSubtractRegion = new System.Windows.Forms.ComboBox();
            this.lbl_forAddCbx = new System.Windows.Forms.Label();
            this.cmbAddRegion = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDisplay
            // 
            this.btnDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisplay.Location = new System.Drawing.Point(73, 32);
            this.btnDisplay.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(84, 32);
            this.btnDisplay.TabIndex = 20;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // dgvBudget
            // 
            this.dgvBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBudget.Location = new System.Drawing.Point(73, 75);
            this.dgvBudget.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvBudget.Name = "dgvBudget";
            this.dgvBudget.RowHeadersWidth = 51;
            this.dgvBudget.Size = new System.Drawing.Size(685, 208);
            this.dgvBudget.TabIndex = 19;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(324, 34);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 28);
            this.comboBox1.TabIndex = 18;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(395, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Region";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(818, 649);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(186, 131);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Budget info";
            this.groupBox1.Visible = false;
            this.groupBox1.VisibleChanged += new System.EventHandler(this.button3_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(818, 360);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(14);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 4;
            this.monthCalendar1.Visible = false;
            this.monthCalendar1.BindingContextChanged += new System.EventHandler(this.UIforBudget);
            // 
            // lblTotalBudget
            // 
            this.lblTotalBudget.AutoSize = true;
            this.lblTotalBudget.Location = new System.Drawing.Point(814, 141);
            this.lblTotalBudget.Name = "lblTotalBudget";
            this.lblTotalBudget.Size = new System.Drawing.Size(51, 20);
            this.lblTotalBudget.TabIndex = 28;
            this.lblTotalBudget.Text = "label6";
            // 
            // lblAvailableAmount
            // 
            this.lblAvailableAmount.AutoSize = true;
            this.lblAvailableAmount.Location = new System.Drawing.Point(814, 184);
            this.lblAvailableAmount.Name = "lblAvailableAmount";
            this.lblAvailableAmount.Size = new System.Drawing.Size(51, 20);
            this.lblAvailableAmount.TabIndex = 29;
            this.lblAvailableAmount.Text = "label7";
            // 
            // lblExcessAmount
            // 
            this.lblExcessAmount.AutoSize = true;
            this.lblExcessAmount.Location = new System.Drawing.Point(814, 237);
            this.lblExcessAmount.Name = "lblExcessAmount";
            this.lblExcessAmount.Size = new System.Drawing.Size(51, 20);
            this.lblExcessAmount.TabIndex = 30;
            this.lblExcessAmount.Text = "label8";
            // 
            // btn_request
            // 
            this.btn_request.Location = new System.Drawing.Point(253, 727);
            this.btn_request.Name = "btn_request";
            this.btn_request.Size = new System.Drawing.Size(305, 44);
            this.btn_request.TabIndex = 31;
            this.btn_request.Text = "Confirm Requests ";
            this.btn_request.UseVisualStyleBackColor = true;
            this.btn_request.Click += new System.EventHandler(this.btn_request_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(71, 302);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 45);
            this.button1.TabIndex = 32;
            this.button1.Text = "Request to add ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(337, 299);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 51);
            this.button2.TabIndex = 33;
            this.button2.Text = "Request to subract ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(589, 299);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(169, 55);
            this.button3.TabIndex = 34;
            this.button3.Text = "Edit the  Date or Lease";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(603, 588);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(155, 41);
            this.btnUpdate.TabIndex = 40;
            this.btnUpdate.Text = "Confirm Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(75, 588);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(122, 41);
            this.btnAdd.TabIndex = 39;
            this.btnAdd.Text = "Confirm Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Visible = false;
            // 
            // txtOperatng
            // 
            this.txtOperatng.Location = new System.Drawing.Point(346, 421);
            this.txtOperatng.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtOperatng.Name = "txtOperatng";
            this.txtOperatng.Size = new System.Drawing.Size(148, 26);
            this.txtOperatng.TabIndex = 38;
            this.txtOperatng.Visible = false;
            // 
            // lbl_operating
            // 
            this.lbl_operating.AutoSize = true;
            this.lbl_operating.Location = new System.Drawing.Point(357, 383);
            this.lbl_operating.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_operating.Name = "lbl_operating";
            this.lbl_operating.Size = new System.Drawing.Size(125, 20);
            this.lbl_operating.TabIndex = 37;
            this.lbl_operating.Text = "Operating costs:";
            this.lbl_operating.Visible = false;
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Location = new System.Drawing.Point(337, 588);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(128, 41);
            this.btnDelete.TabIndex = 41;
            this.btnDelete.Text = "Confirm Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Visible = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(589, 509);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 46;
            this.dateTimePicker1.Visible = false;
            // 
            // txtLease
            // 
            this.txtLease.Location = new System.Drawing.Point(589, 421);
            this.txtLease.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLease.Name = "txtLease";
            this.txtLease.Size = new System.Drawing.Size(148, 26);
            this.txtLease.TabIndex = 36;
            this.txtLease.Visible = false;
            // 
            // lblForDelCBX
            // 
            this.lblForDelCBX.AutoSize = true;
            this.lblForDelCBX.Location = new System.Drawing.Point(357, 468);
            this.lblForDelCBX.Name = "lblForDelCBX";
            this.lblForDelCBX.Size = new System.Drawing.Size(106, 20);
            this.lblForDelCBX.TabIndex = 45;
            this.lblForDelCBX.Text = "Subtract from";
            this.lblForDelCBX.Visible = false;
            // 
            // lbl_lease
            // 
            this.lbl_lease.AutoSize = true;
            this.lbl_lease.Location = new System.Drawing.Point(583, 383);
            this.lbl_lease.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_lease.Name = "lbl_lease";
            this.lbl_lease.Size = new System.Drawing.Size(57, 20);
            this.lbl_lease.TabIndex = 35;
            this.lbl_lease.Text = "Lease:";
            this.lbl_lease.Visible = false;
            // 
            // cmbSubtractRegion
            // 
            this.cmbSubtractRegion.FormattingEnabled = true;
            this.cmbSubtractRegion.Location = new System.Drawing.Point(337, 507);
            this.cmbSubtractRegion.Name = "cmbSubtractRegion";
            this.cmbSubtractRegion.Size = new System.Drawing.Size(157, 28);
            this.cmbSubtractRegion.TabIndex = 43;
            this.cmbSubtractRegion.Visible = false;
            // 
            // lbl_forAddCbx
            // 
            this.lbl_forAddCbx.AutoSize = true;
            this.lbl_forAddCbx.Location = new System.Drawing.Point(80, 468);
            this.lbl_forAddCbx.Name = "lbl_forAddCbx";
            this.lbl_forAddCbx.Size = new System.Drawing.Size(105, 20);
            this.lbl_forAddCbx.TabIndex = 44;
            this.lbl_forAddCbx.Text = "Where to add";
            this.lbl_forAddCbx.Visible = false;
            // 
            // cmbAddRegion
            // 
            this.cmbAddRegion.FormattingEnabled = true;
            this.cmbAddRegion.Location = new System.Drawing.Point(61, 511);
            this.cmbAddRegion.Name = "cmbAddRegion";
            this.cmbAddRegion.Size = new System.Drawing.Size(155, 28);
            this.cmbAddRegion.TabIndex = 42;
            this.cmbAddRegion.Visible = false;
            // 
            // Budget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 794);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtOperatng);
            this.Controls.Add(this.lbl_operating);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtLease);
            this.Controls.Add(this.lblForDelCBX);
            this.Controls.Add(this.lbl_lease);
            this.Controls.Add(this.cmbSubtractRegion);
            this.Controls.Add(this.lbl_forAddCbx);
            this.Controls.Add(this.cmbAddRegion);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_request);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.lblExcessAmount);
            this.Controls.Add(this.lblAvailableAmount);
            this.Controls.Add(this.lblTotalBudget);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.dgvBudget);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Budget";
            this.Text = "Budget";
            this.Load += new System.EventHandler(this.Budget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.DataGridView dgvBudget;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label lblTotalBudget;
        private System.Windows.Forms.Label lblAvailableAmount;
        private System.Windows.Forms.Label lblExcessAmount;
        private System.Windows.Forms.Button btn_request;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtOperatng;
        private System.Windows.Forms.Label lbl_operating;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtLease;
        private System.Windows.Forms.Label lblForDelCBX;
        private System.Windows.Forms.Label lbl_lease;
        private System.Windows.Forms.ComboBox cmbSubtractRegion;
        private System.Windows.Forms.Label lbl_forAddCbx;
        private System.Windows.Forms.ComboBox cmbAddRegion;
    }
}