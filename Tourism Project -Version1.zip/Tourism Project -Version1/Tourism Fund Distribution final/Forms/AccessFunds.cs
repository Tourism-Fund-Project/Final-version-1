﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class AccessFunds : Form
    {
        public AccessFunds()
        {
            InitializeComponent();

        }

        private void AccessFunds_Load(object sender, EventArgs e)
        {
            LoadTheme();
            LoadTouristAttractions();
            btnDisplayExisting.Click += new EventHandler(btnDisplay_Click);


        }
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
        }
        private void DisplayTouristAttractionData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    conn.Open();

                    // Get the selected TouristAttraction_ID from the combo box
                    int selectedAttractionID = Convert.ToInt32(comboBox1.SelectedValue);

                    // Adjusted query to ensure AccessFunds_ID matches
                    string query = @" SELECT af.AccessFunds_ID, ta.Name, af.[Attraction Development Fee], af.[Repairs Fee], af.Date FROM  TouristAttraction ta JOIN Access_Funds af ON ta.AccessFunds_ID = af.AccessFunds_ID WHERE  ta.TouristAttraction_ID = @TouristAttractionID";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TouristAttractionID", selectedAttractionID);

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        // Debugging: Check the content of the DataTable
                        foreach (DataRow row in dt.Rows)
                        {
                            Console.WriteLine($"AccessFunds_ID: {row["AccessFunds_ID"]}, Name: {row["Name"]}, Attraction Development Fee: {row["Attraction Development Fee"]}, Repairs Fee: {row["Repairs Fee"]}, Date: {row["Date"]}");
                        }

                        // Ensure the DataGridView columns are correctly set
                        dataGridView1.AutoGenerateColumns = false;
                        dataGridView1.Columns.Clear();

                        dataGridView1.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "AccessFunds_ID", HeaderText = "Access Funds ID" });
                        dataGridView1.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Name", HeaderText = "Attraction Name" });
                        dataGridView1.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Attraction Development Fee", HeaderText = "Development Fee" });
                        dataGridView1.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Repairs Fee", HeaderText = "Repairs Fee" });
                        dataGridView1.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Date", HeaderText = "Date" });

                        dataGridView1.DataSource = dt;
                        MessageBox.Show("Data Retrieved!");
                    }
                    else
                    {
                        MessageBox.Show("No data found for the selected tourist attraction.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}\n\nError details: {ex.StackTrace}",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void LoadTouristAttractions()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    conn.Open();
                    string query = "SELECT TouristAttraction_ID, Name FROM TouristAttraction";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        comboBox1.DataSource = dt;
                        comboBox1.DisplayMember = "Name";
                        comboBox1.ValueMember = "TouristAttraction_ID";
                    }
                    else
                    {
                        MessageBox.Show("No tourist attractions found."); // Debugging step
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message); // Error handling
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DisplayTouristAttractionData();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int attractionID = (int)comboBox1.SelectedValue;
                string query = @"SELECT  ta.Name, r.Region_ID, rev.Performance_Rank, af.AccessFunds_ID,  af.[Repairs Fee] FROM   TouristAttraction ta JOIN Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID JOIN Regions r ON ta.Region_ID = r.Region_ID
                JOIN 
                Access_Funds af ON ta.AccessFunds_ID = af.AccessFunds_ID
                WHERE 
                ta.TouristAttraction_ID = @AttractionID";

                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    conn.Open();
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    sda.SelectCommand.Parameters.AddWithValue("@AttractionID", attractionID);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        int regionID = Convert.ToInt32(dt.Rows[0]["Region_ID"]);
                        decimal totalBudget = 1200000000m; // 1.2 billion Rand

                        // Calculate regional budget based on the average performance rank
                        decimal regionalBudget = CalculateRegionalBudget(regionID, totalBudget);

                        // Calculate the development fee based on the regional budget
                        decimal devFee = CalculateDevelopmentFee(attractionID, regionalBudget);

                        // Update the DataTable with the new values
                        dt.Columns.Add("Attraction Development Fee", typeof(decimal));
                        dt.Columns.Add("Date", typeof(DateTime));

                        // Set the calculated values
                        dt.Rows[0]["Attraction Development Fee"] = devFee;
                        dt.Rows[0]["Date"] = DateTime.Now;

                        // Display the data in the DataGridView
                        dataGridView2.DataSource = dt;

                        // Set column headers for clarity
                        dataGridView2.Columns["AccessFunds_ID"].HeaderText = "Access Funds ID";
                        dataGridView2.Columns["Name"].HeaderText = "Attraction Name";
                        dataGridView2.Columns["Attraction Development Fee"].HeaderText = "Development Fee";
                        dataGridView2.Columns["Repairs Fee"].HeaderText = "Repairs Fee";
                        dataGridView2.Columns["Date"].HeaderText = "Date";

                        MessageBox.Show("Data and calculations updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No data found for the selected tourist attraction.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private decimal CalculateRegionalBudget(int regionID, decimal totalBudget)
        {
            decimal regionalBudget = 0;

            try
            {
                string query = @"
            SELECT AVG(rev.Performance_Rank) AS AvgPerformanceRank
            FROM TouristAttraction ta
            JOIN Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
            WHERE ta.Region_ID = @RegionID";

                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@RegionID", regionID);

                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        decimal avgPerformanceRank = Convert.ToDecimal(result);

                        // Use the average performance rank to determine the regional budget
                        regionalBudget = totalBudget * (avgPerformanceRank / 10); // Assuming max rank is 10
                    }
                    else
                    {
                        MessageBox.Show("No performance rank data found for this region.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while calculating the regional budget: {ex.Message}");
            }

            return regionalBudget;
        }

        private decimal CalculateDevelopmentFee(int attractionID, decimal regionalBudget)
        {
            decimal developmentFee = 0;

            try
            {
                string query = @"SELECT rev.Performance_Rank FROM TouristAttraction ta JOIN Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID WHERE ta.TouristAttraction_ID = @AttractionID";

                using (SqlConnection conn = new SqlConnection("Data Source = MSI\\SQLEXPRESS;Initial Catalog = TouristAttractionDB111; Integrated Security = True"))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AttractionID", attractionID);

                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        int rank = Convert.ToInt32(result);

                        if (rank >= 8 && rank <= 10)
                        {
                            // Fixed amount for ranks 8-10
                            developmentFee = regionalBudget * 0.30m / 3; // Assuming 30% of the regional budget is evenly distributed
                        }
                        else
                        {
                            // Allocate remaining 70% of the regional budget for ranks 1-7, with lower ranks getting more
                            decimal remainingBudget = regionalBudget * 0.70m;
                            decimal rankWeight = (7 - (rank - 1)) / 21m; // Adjust rank weight (sum of 1+2+...+7 = 28)
                            developmentFee = remainingBudget * rankWeight;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No rank data found for this attraction.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while calculating the development fee: {ex.Message}");
            }

            return developmentFee;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView2.Rows.Count > 0)
            {
                string attractionName = dataGridView2.Rows[0].Cells["Name"].Value.ToString();
                decimal devFee = Convert.ToDecimal(dataGridView2.Rows[0].Cells["Attraction Development Fee"].Value);
                decimal repairsFee = Convert.ToDecimal(dataGridView2.Rows[0].Cells["Repairs Fee"].Value);
                DateTime date = Convert.ToDateTime(dataGridView2.Rows[0].Cells["Date"].Value);

                listBox1.Items.Clear();
                listBox1.Items.Add($"Recommended Fund Allocation for {attractionName}:");
                listBox1.Items.Add($"Attraction Development Fee - {devFee:C}");
                listBox1.Items.Add($"Repairs Fee - {repairsFee:C}");
                listBox1.Items.Add($"Date - {date.ToShortDateString()}");
            }
            else
            {
                MessageBox.Show("Please calculate the recommended fees first.");
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }
