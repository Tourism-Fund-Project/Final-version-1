﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Tourist_Attractions : Form
    {
        public Tourist_Attractions()
        {
            InitializeComponent();
           // 
        }
        
        private void Tourist_Attractions_Load(object sender, EventArgs e)
        {
            LoadTheme();
            LoadCategories();
            //LoadTouristAttractions();
         
            //LoadTouristAttractionDB();
            PopulateComboBox();
        }
        private string connectionString = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True";

        private void PopulateComboBox()
        {
           string[] provinces = { "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", "Mpumalanga", "North-West", "Northern Cape", "Western Cape" };
            cbxRegion.Items.AddRange(provinces);
            cbxRegion2Add.Items.AddRange(provinces);
        }
        
        private void FilterRegionsByProvince(string province)
        {
            string query = $"SELECT * FROM TouristAttraction WHERE Region LIKE '{province}%'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    TouristAttractionDgv.DataSource = dataTable; // Bind the filtered data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        private void LoadTouristAttractionDB()
        {
            string query = "SELECT * FROM dbo.TouristAttraction";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    TouristAttractionDgv.DataSource = dataTable; // Bind the DataTable to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void ClearTextBoxes()
        {
            txtName.Clear();
            txtDescription.Clear();
           
            cbxRegion.SelectedIndex = -1; // Reset ComboBox selection if needed
        }



        private void LoadCategories()
        {
            
            string sqlCategories = "SELECT Category_ID, Name FROM Category_TA";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(sqlCategories, connection);
                DataTable categories = new DataTable();
                adapter.Fill(categories);

                cbxCategory.DataSource = categories;
                cbxCategory.DisplayMember = "Name";
                cbxCategory.ValueMember = "Category_ID";
            }
        }
       
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
        }

       

      
        private void btnAdd_Click(object sender, EventArgs e)
        {

            string name = txtName.Text;
            string description = txtDescription.Text;
            int selectedCategory = (int)cbxCategory.SelectedValue;
            string regionstoMaintain = cbxRegion2Add.SelectedItem.ToString();
            //int selectedRegion = (int)cbxRegion.SelectedValue;
            //string connectionString = ""; // Your DB connection string here

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(description) || cbxCategory.SelectedIndex == -1 || cbxRegion2Add.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all details and ensure a category and region have been selected.");
                return;
            }

            string sqlTA = "INSERT INTO dbo.TouristAttraction (Name, Description,Region) VALUES (@Name, @Description, @Region)";
            string sqlTA2 = "INSERT INTO dbo.Category_TA (Name) VALUES (@CategoryName)";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(sqlTA, connection);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Description", description);
                    cmd.Parameters.AddWithValue("@Region", regionstoMaintain);
                    SqlCommand cmd2 = new SqlCommand(sqlTA2, connection);
                    cmd.Parameters.AddWithValue("@Category_ID", selectedCategory);
                    
                    connection.Open();
                    int itemAdded = cmd.ExecuteNonQuery();
                    
                    MessageBox.Show(itemAdded > 0 ? "Attraction added successfully!" : "Failed to add attraction");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
            ClearTextBoxes();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (TouristAttractionDgv.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedAttraction = TouristAttractionDgv.SelectedRows[0];
                int TouristAttractionID = Convert.ToInt32(selectedAttraction.Cells["TouristAttraction_ID"].Value);
                string name = txtName.Text;
                string description = txtDescription.Text;
                string regionstoMaintain = cbxRegion2Add.SelectedItem.ToString();
                string sqlTA = "UPDATE dbo.TouristAttraction SET Name = @Name, Description = @Description, Region = @Region WHERE TouristAttraction_ID = @TouristAttraction_ID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand(sqlTA, connection);
                        cmd.Parameters.AddWithValue("@TouristAttraction_ID", TouristAttractionID);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Description", description);
                        cmd.Parameters.AddWithValue("@Region", regionstoMaintain);
                        connection.Open();
                        int itemUpdated = cmd.ExecuteNonQuery();
                        MessageBox.Show(itemUpdated > 0 ? "Update was successful." : name + " does not exist.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a Tourist Attraction");
            }

            MessageBox.Show("IKA");


        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (TouristAttractionDgv.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedAttraction = TouristAttractionDgv.SelectedRows[0];
                int TouristAttractionID = Convert.ToInt32(selectedAttraction.Cells["TouristAttraction_ID"].Value);
                //string connectionString = ""; // Your DB connection string here
                string sqlTA = "DELETE FROM dbo.TouristAttraction WHERE TouristAttraction_ID = @TouristAttraction_ID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand(sqlTA, connection);
                        cmd.Parameters.AddWithValue("@TouristAttraction_ID", TouristAttractionID);
                        connection.Open();
                        int itemsDeleted = cmd.ExecuteNonQuery();
                        MessageBox.Show(itemsDeleted > 0 ? "You have deleted the attraction from the database." : "Failed to delete the attraction");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an Attraction to delete");
            }

            MessageBox.Show("IKA");

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            LoadTouristAttractionDB();

            
            //LoadRegionsDB();
            MessageBox.Show("IKA");
        }

        private void cbxRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedProvince = cbxRegion.SelectedItem.ToString();
           
            if (!string.IsNullOrEmpty(selectedProvince))
            {

                FilterRegionsByProvince(selectedProvince);
            }
            else
            {
                MessageBox.Show("No Province Selected");
            }
        }

        private void cbxRegion2Add_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ProvinceToMaintain = cbxRegion2Add.SelectedItem.ToString();
        }
    }

}



