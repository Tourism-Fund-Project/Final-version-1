﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class AccessFunds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TouristAttractionDgv = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnDistribute = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_Filter_AccessFunds = new System.Windows.Forms.Button();
            this.cbx_Filter_Province = new System.Windows.Forms.ComboBox();
            this.txt_Filter_TAName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TouristAttractionDgv)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // TouristAttractionDgv
            // 
            this.TouristAttractionDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TouristAttractionDgv.Location = new System.Drawing.Point(45, 338);
            this.TouristAttractionDgv.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TouristAttractionDgv.Name = "TouristAttractionDgv";
            this.TouristAttractionDgv.RowHeadersWidth = 62;
            this.TouristAttractionDgv.Size = new System.Drawing.Size(699, 212);
            this.TouristAttractionDgv.TabIndex = 24;
            this.TouristAttractionDgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAccess1_CellContentClick);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(336, 40);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 28);
            this.comboBox1.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 102);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Province";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(807, 338);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(544, 498);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Results";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(9, 29);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(524, 444);
            this.listBox1.TabIndex = 0;
            // 
            // btnDistribute
            // 
            this.btnDistribute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDistribute.Location = new System.Drawing.Point(282, 855);
            this.btnDistribute.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDistribute.Name = "btnDistribute";
            this.btnDistribute.Size = new System.Drawing.Size(218, 42);
            this.btnDistribute.TabIndex = 27;
            this.btnDistribute.Text = "Affirm Distribution";
            this.toolTip2.SetToolTip(this.btnDistribute, "Affirms that Funds have been distributed correctly");
            this.btnDistribute.UseVisualStyleBackColor = true;
            this.btnDistribute.Click += new System.EventHandler(this.btnDistribute_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(45, 629);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.Size = new System.Drawing.Size(699, 208);
            this.dataGridView2.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 309);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "Existing Allocation of Funds";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 600);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(266, 20);
            this.label3.TabIndex = 31;
            this.label3.Text = " Recommended Allocation of Funds ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.btn_Filter_AccessFunds);
            this.groupBox3.Controls.Add(this.cbx_Filter_Province);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(50, 65);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(543, 240);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Tourist Attractions by";
            // 
            // btn_Filter_AccessFunds
            // 
            this.btn_Filter_AccessFunds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_AccessFunds.Location = new System.Drawing.Point(298, 188);
            this.btn_Filter_AccessFunds.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Filter_AccessFunds.Name = "btn_Filter_AccessFunds";
            this.btn_Filter_AccessFunds.Size = new System.Drawing.Size(218, 42);
            this.btn_Filter_AccessFunds.TabIndex = 33;
            this.btn_Filter_AccessFunds.Text = " Show recomended";
            this.toolTip1.SetToolTip(this.btn_Filter_AccessFunds, "Displays Tourist Attractions According to inputs provided");
            this.btn_Filter_AccessFunds.UseVisualStyleBackColor = true;
            this.btn_Filter_AccessFunds.Click += new System.EventHandler(this.btn_Filter_AccessFunds_Click);
            // 
            // cbx_Filter_Province
            // 
            this.cbx_Filter_Province.FormattingEnabled = true;
            this.cbx_Filter_Province.Location = new System.Drawing.Point(336, 94);
            this.cbx_Filter_Province.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbx_Filter_Province.Name = "cbx_Filter_Province";
            this.cbx_Filter_Province.Size = new System.Drawing.Size(180, 28);
            this.cbx_Filter_Province.TabIndex = 32;
            this.cbx_Filter_Province.SelectedIndexChanged += new System.EventHandler(this.cbx_Filter_Province_SelectedIndexChanged);
            // 
            // txt_Filter_TAName
            // 
            this.txt_Filter_TAName.Location = new System.Drawing.Point(648, 31);
            this.txt_Filter_TAName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Filter_TAName.Name = "txt_Filter_TAName";
            this.txt_Filter_TAName.Size = new System.Drawing.Size(148, 26);
            this.txt_Filter_TAName.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 43);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Name";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Click";
            // 
            // toolTip2
            // 
            this.toolTip2.IsBalloon = true;
            this.toolTip2.ToolTipTitle = "Click";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(225, 42);
            this.button1.TabIndex = 34;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AccessFunds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 915);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Filter_TAName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnDistribute);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TouristAttractionDgv);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "AccessFunds";
            this.Text = "AccessFunds";
            this.Load += new System.EventHandler(this.AccessFunds_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TouristAttractionDgv)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView TouristAttractionDgv;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnDistribute;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbx_Filter_Province;
        private System.Windows.Forms.TextBox txt_Filter_TAName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_Filter_AccessFunds;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.Button button1;
    }
}