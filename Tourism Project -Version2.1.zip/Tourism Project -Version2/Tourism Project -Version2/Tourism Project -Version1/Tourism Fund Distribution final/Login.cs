﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void validateLogin()
        {
            string userName = txtUserName.Text;
            string password = txtPassword.Text;

            string[] userNames = { "SystemAdmin", "AttractionSupervisor", "FinancialOfficer" };
            string[] userPasswords = { "41380525", "31765432", "46290303" };
            string[] userRoles = { "SystemAdmin", "AttractionSupervisor", "FinancialOfficer" };

            bool isValid = false;
            int userIndex = -1;

            for (int i = 0; i < userNames.Length; i++)
            {
                if (userName == userNames[i] && password == userPasswords[i])
                {
                    isValid = true;
                    userIndex = i;
                    break;
                }
            }

            if (isValid)
            {
                // Store the user's role and username
                UserSession.UserRole = userRoles[userIndex];
                UserSession.UserName = userName;

                // Proceed to the home form
                Form1 home = new Form1();
                home.Show();
                this.Hide();
            }
            else
            {
                lbl_UN_Error.Visible = true;
                lbl_Password_Error.Visible = true;
            }
        }



        private void txtLogin_Click(object sender, EventArgs e)
        {
            validateLogin();

            // Check if the login is valid
            if (lbl_UN_Error.Visible || lbl_Password_Error.Visible)
            {
                // Show error messages if login is invalid
                return;
                
            }
            txtUserName.Text = " ";
            txtPassword.Text = " ";

            // Proceed to the home form if login is valid
            Form1 Home = new Form1();
            Home.userName = txtUserName.Text;
            Home.Show();
            this.Hide();
        }

        private void check_showPassword_CheckedChanged(object sender, EventArgs e)
        {
           
            if (check_showPassword.Checked)
            {
                // If checked, display the password as plain text
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                // If unchecked, mask the password with '*'
                txtPassword.PasswordChar = '*';
            }
        }

        
        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
