﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Data.SqlClient;
using System.Net.NetworkInformation;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class PieChart_Report : Form
    {
        public PieChart_Report()
        {
            InitializeComponent();

        }
        private void PieChart_Report_Load(object sender, EventArgs e)
        {
            string query = @"
    SELECT 
 
        SUM(rev.Number_of_Tourists) AS [Total Tourists],
        b.Region_Name AS [Budget Region_Name]
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    JOIN 
        Regions r ON ta.Region_ID = r.Region_ID
    JOIN 
        Budget b ON r.Name LIKE '%' + b.Region_Name + '%'
    GROUP BY 
        b.Region_Name";

            using (SqlConnection conn = new SqlConnection("Data Source=Project-Scarlet\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                // Debugging: Check the number of rows returned
                if (dt.Rows.Count > 0)
                {
                    pieChart2.Series.Clear();

                    foreach (DataRow row in dt.Rows)
                    {
                        string regionName = row["Budget Region_Name"].ToString();
                        double totalTourists = Convert.ToDouble(row["Total Tourists"]);

                        pieChart2.Series.Add(new PieSeries
                        {
                            Title = regionName,
                            Values = new ChartValues<double> { totalTourists }
                        });
                    }


                }
                else
                {
                    MessageBox.Show("No data found for the query. Please verify the query and the database.");
                }
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void elementHost1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }
    }
}
