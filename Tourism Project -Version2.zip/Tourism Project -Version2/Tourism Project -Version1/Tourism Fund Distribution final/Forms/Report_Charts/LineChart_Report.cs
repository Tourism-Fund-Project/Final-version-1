﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Media;

namespace Tourism_Fund_Distribution_final.Forms.Report_Charts
{
    public partial class LineChart_Report : Form
    {
        public LineChart_Report()
        {
            InitializeComponent();

        }


        private void LineChart_Report_Load(object sender, EventArgs e)
        {

            string queryLowest = @"
    SELECT 
        ta.Name AS [Attraction Name], 
        rev.Number_of_Tourists, 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    ORDER BY 
        rev.Performance_Rank ASC
    OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY;
    ";

            using (SqlConnection conn = new SqlConnection("Data Source=Project-Scarlet\\SQLEXPRESS;Initial Catalog=TouristAttractionDB111;Integrated Security=True;Encrypt=False"))
            {
                conn.Open();


                // Retrieve lowest performance ranks
                SqlDataAdapter sdaLowest = new SqlDataAdapter(queryLowest, conn);
                DataTable dtLowest = new DataTable();
                sdaLowest.Fill(dtLowest);

                MessageBox.Show("Data Retrieved!"); // Debugging step

                if (dtLowest.Rows.Count > 0)
                {
                    cartesianChart1.Series.Clear();

                    var touristsSeries = new ColumnSeries
                    {
                        Title = "Number of Tourists",
                        Values = new ChartValues<int>(),
                        MaxColumnWidth = 80 // Adjust width to minimize space between columns
                    };

                    var rankSeries = new ColumnSeries
                    {
                        Title = "Performance Rank",
                        Values = new ChartValues<int>(),
                        MaxColumnWidth = 80 // Adjust width to minimize space between columns
                    };



                    // Adding data to the lowest series
                    foreach (DataRow row in dtLowest.Rows)
                    {
                        touristsSeries.Values.Add(Convert.ToInt32(row["Number_of_Tourists"]));
                        rankSeries.Values.Add(Convert.ToInt32(row["Performance_Rank"]));
                    }

                    cartesianChart1.Series.Add(touristsSeries);
                    cartesianChart1.Series.Add(rankSeries);

                    // X-Axis configuration
                    cartesianChart1.AxisX.Add(new Axis
                    {
                        Title = "Attraction Name",
                        Labels = dtLowest.AsEnumerable().Select(x => x["Attraction Name"].ToString()).Concat(dtLowest.AsEnumerable().Select(x => x["Attraction Name"].ToString())).Distinct().ToArray(),
                        Separator = new Separator
                        {
                            Step = 1, // Ensure the labels are not too close
                        }
                    });

                    // Y-Axis configuration
                    cartesianChart1.AxisY.Add(new Axis
                    {
                        Title = "Number of Tourists",
                        LabelFormatter = value => value.ToString()
                    });

                    cartesianChart1.Visibility = System.Windows.Visibility.Visible;
                    MessageBox.Show("Chart Updated!"); // Debugging step
                }
                else
                {
                    MessageBox.Show("No data found for the query."); // Debugging step
                }

                string queryhighest = @"
    SELECT 
        ta.Name AS [Attraction Name], 
        rev.Number_of_Tourists, 
        rev.Performance_Rank 
    FROM 
        TouristAttraction ta
    JOIN 
        Reviews rev ON ta.TouristAttraction_ID = rev.TouristAttraction_ID
    ORDER BY 
        rev.Performance_Rank DESC
    OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY;
    ";


                // Retrieve lowest performance ranks
                SqlDataAdapter sdahighest = new SqlDataAdapter(queryhighest, conn);
                DataTable dthighest = new DataTable();
                sdahighest.Fill(dthighest);


                if (dthighest.Rows.Count > 0)
                {
                    cartesianChart2.Series.Clear();

                    var touristsSeries = new ColumnSeries
                    {
                        Title = "Number of Tourists",
                        Values = new ChartValues<int>(),
                        MaxColumnWidth = 80 // Adjust width to minimize space between columns
                    };

                    var rankSeries = new ColumnSeries
                    {
                        Title = "Performance Rank",
                        Values = new ChartValues<int>(),
                        MaxColumnWidth = 80 // Adjust width to minimize space between columns
                    };



                    // Adding data to the lowest series
                    foreach (DataRow row in dthighest.Rows)
                    {
                        touristsSeries.Values.Add(Convert.ToInt32(row["Number_of_Tourists"]));
                        rankSeries.Values.Add(Convert.ToInt32(row["Performance_Rank"]));
                    }

                    cartesianChart2.Series.Add(touristsSeries);
                    cartesianChart2.Series.Add(rankSeries);

                    // X-Axis configuration
                    cartesianChart2.AxisX.Add(new Axis
                    {
                        Title = "Attraction Name",
                        Labels = dthighest.AsEnumerable().Select(x => x["Attraction Name"].ToString()).Concat(dthighest.AsEnumerable().Select(x => x["Attraction Name"].ToString())).Distinct().ToArray(),
                        Separator = new Separator
                        {
                            Step = 1, // Ensure the labels are not too close
                        }
                    });

                    // Y-Axis configuration
                    cartesianChart2.AxisY.Add(new Axis
                    {
                        Title = "Number of Tourists",
                        LabelFormatter = value => value.ToString()
                    });

                    cartesianChart2.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("No data found for the query."); // Debugging step
                }
            }


        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
