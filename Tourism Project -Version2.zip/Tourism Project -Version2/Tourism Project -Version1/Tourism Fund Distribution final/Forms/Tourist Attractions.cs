﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Tourist_Attractions : Form
    {
        public Tourist_Attractions()
        {
            InitializeComponent();
            // 
        }

        private void Tourist_Attractions_Load(object sender, EventArgs e)
        {
            LoadTheme();
           // LoadCategories();
            //LoadTouristAttractions();

            //LoadTouristAttractionDB();
            //PopulateComboBox();
        }
        
        
        

        


        

        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
            }
            label1.ForeColor = ThemeColour.SecondaryColor;
            label2.ForeColor = ThemeColour.PrimaryColor;
            label3.ForeColor = ThemeColour.PrimaryColor;
            label4.ForeColor = ThemeColour.PrimaryColor;
            label5.ForeColor = ThemeColour.PrimaryColor;
            label6.ForeColor = ThemeColour.PrimaryColor;
            label7.ForeColor = ThemeColour.PrimaryColor;
            label8.ForeColor = ThemeColour.PrimaryColor;
            label9.ForeColor = ThemeColour.PrimaryColor;
        }



    }

}



