﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.btnTopPerRegion = new System.Windows.Forms.Button();
            this.btnTopRanked = new System.Windows.Forms.Button();
            this.btnTopTourists = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnViewPieChart = new System.Windows.Forms.Button();
            this.btnViewGraph = new System.Windows.Forms.Button();
            this.grpOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpOptions
            // 
            this.grpOptions.Controls.Add(this.btnTopPerRegion);
            this.grpOptions.Controls.Add(this.btnTopRanked);
            this.grpOptions.Controls.Add(this.btnTopTourists);
            this.grpOptions.Location = new System.Drawing.Point(27, 255);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(339, 104);
            this.grpOptions.TabIndex = 3;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Reports Avalible";
            // 
            // btnTopPerRegion
            // 
            this.btnTopPerRegion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTopPerRegion.Location = new System.Drawing.Point(230, 20);
            this.btnTopPerRegion.Name = "btnTopPerRegion";
            this.btnTopPerRegion.Size = new System.Drawing.Size(109, 65);
            this.btnTopPerRegion.TabIndex = 5;
            this.btnTopPerRegion.Text = "Top Tourist Attractions per Region";
            this.btnTopPerRegion.UseVisualStyleBackColor = true;
//            this.btnTopPerRegion.Click += new System.EventHandler(this.btnTopPerRegion_Click_1);
            // 
            // btnTopRanked
            // 
            this.btnTopRanked.BackColor = System.Drawing.SystemColors.Control;
            this.btnTopRanked.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTopRanked.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTopRanked.Location = new System.Drawing.Point(0, 20);
            this.btnTopRanked.Name = "btnTopRanked";
            this.btnTopRanked.Size = new System.Drawing.Size(109, 65);
            this.btnTopRanked.TabIndex = 3;
            this.btnTopRanked.Text = "Top 10 Ranked Tourist Attractions";
            this.btnTopRanked.UseVisualStyleBackColor = false;
//            this.btnTopRanked.Click += new System.EventHandler(this.btnTopRanked_Click);
            // 
            // btnTopTourists
            // 
            this.btnTopTourists.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTopTourists.Location = new System.Drawing.Point(115, 20);
            this.btnTopTourists.Name = "btnTopTourists";
            this.btnTopTourists.Size = new System.Drawing.Size(109, 65);
            this.btnTopTourists.TabIndex = 4;
            this.btnTopTourists.Text = "Tourist Attractions that had the Most Tourists";
            this.btnTopTourists.UseVisualStyleBackColor = true;
//            this.btnTopTourists.Click += new System.EventHandler(this.btnTopTourists_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(67, 26);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(644, 223);
            this.dataGridView1.TabIndex = 4;
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Location = new System.Drawing.Point(27, 365);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 51);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear\r\n";
            this.btnClear.UseVisualStyleBackColor = true;
 //           this.btnClear.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnViewPieChart);
            this.groupBox1.Controls.Add(this.btnViewGraph);
            this.groupBox1.Location = new System.Drawing.Point(381, 255);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(350, 104);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Charts Avalible";
            // 
            // btnViewPieChart
            // 
            this.btnViewPieChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewPieChart.Location = new System.Drawing.Point(193, 20);
            this.btnViewPieChart.Name = "btnViewPieChart";
            this.btnViewPieChart.Size = new System.Drawing.Size(109, 65);
            this.btnViewPieChart.TabIndex = 9;
            this.btnViewPieChart.Text = "Total Number of Tourists per Region";
            this.btnViewPieChart.UseVisualStyleBackColor = true;
 //           this.btnViewPieChart.Click += new System.EventHandler(this.btnViewPieChart_Click);
            // 
            // btnViewGraph
            // 
            this.btnViewGraph.BackColor = System.Drawing.SystemColors.Control;
            this.btnViewGraph.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnViewGraph.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnViewGraph.Location = new System.Drawing.Point(54, 20);
            this.btnViewGraph.Name = "btnViewGraph";
            this.btnViewGraph.Size = new System.Drawing.Size(109, 65);
            this.btnViewGraph.TabIndex = 0;
            this.btnViewGraph.Text = "Highest Ranked Tourist Attractions vs Lowest Ranked Attractions\r\n";
            this.btnViewGraph.UseVisualStyleBackColor = false;
 //           this.btnViewGraph.Click += new System.EventHandler(this.btnViewGraph_Click_1);
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 456);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.grpOptions);
            this.Name = "Reports";
            this.Text = "Reports";
            this.Load += new System.EventHandler(this.Reports_Load);
            this.grpOptions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox grpOptions;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnViewGraph;
        private System.Windows.Forms.Button btnTopPerRegion;
        private System.Windows.Forms.Button btnTopRanked;
        private System.Windows.Forms.Button btnTopTourists;
        private System.Windows.Forms.Button btnViewPieChart;
    }
}