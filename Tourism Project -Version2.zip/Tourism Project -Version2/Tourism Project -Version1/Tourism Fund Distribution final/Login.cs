﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtLogin_Click(object sender, EventArgs e)
        {
            if(txtUserName.Text == "" && txtPassword.Text == "")
            {
                lbl_Password_Error.Visible = true;
                lbl_UN_Error.Visible = true;
            }
            else
            {
                Form1 Home = new Form1();
                Home.Show();
                this.Hide();
            }
            

        }

        private void check_showPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = check_showPassword.Checked ? '*' : '\0';
        }
    }
}
