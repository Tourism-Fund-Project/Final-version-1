﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Markup;
using LiveCharts;
using LiveCharts.Definitions.Charts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;
using Tourism_Fund_Distribution_final.Forms.Report_Charts;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class Reports : Form
    {
        public Reports()
        {
            InitializeComponent();
            
            
        }
        

        private void Reports_Load(object sender, EventArgs e)
        {
            
        }


    }
}
