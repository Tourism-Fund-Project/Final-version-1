﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tourism_Fund_Distribution_final.Forms
{
    public partial class AccessFunds : Form
    {
        public AccessFunds()
        {
            InitializeComponent();

        }

        private void AccessFunds_Load(object sender, EventArgs e)
        {
            LoadTheme(this);
            


        }
        private void LoadTheme(Control Form1)
        {
            foreach (Control control in Form1.Controls)
            {
                if (control is Button)
                {
                    Button btn = (Button)control;
                    btn.BackColor = ThemeColour.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColour.SecondaryColor;
                }
                else if (control is Label)
                {
                    Label lbl = (Label)control;
                    lbl.ForeColor = ThemeColour.PrimaryColor;
                }


                LoadTheme(control);
            }
        }

    }
}
