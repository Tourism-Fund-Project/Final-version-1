﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Budget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvBudget = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotalBudget = new System.Windows.Forms.Label();
            this.lblAvailableAmount = new System.Windows.Forms.Label();
            this.lblExcessAmount = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Filter_Budget_OC = new System.Windows.Forms.TextBox();
            this.lbl_Filter_Budget_Date = new System.Windows.Forms.Label();
            this.txt_Filter_Budget_Lease = new System.Windows.Forms.TextBox();
            this.lbl_Filter_Budget_OperatingCosts = new System.Windows.Forms.Label();
            this.lbl_Filter_Budget_Lease = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cbx_Lease_OC = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtLease = new System.Windows.Forms.TextBox();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_Filter_Budget = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.txtProvince_Add = new System.Windows.Forms.TextBox();
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.checkBox_BudgetApprove = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvBudget
            // 
            this.dgvBudget.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBudget.Location = new System.Drawing.Point(39, 224);
            this.dgvBudget.Name = "dgvBudget";
            this.dgvBudget.RowHeadersWidth = 51;
            this.dgvBudget.Size = new System.Drawing.Size(457, 135);
            this.dgvBudget.TabIndex = 19;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(372, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(419, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Province";
            // 
            // lblTotalBudget
            // 
            this.lblTotalBudget.AutoSize = true;
            this.lblTotalBudget.Location = new System.Drawing.Point(719, 97);
            this.lblTotalBudget.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalBudget.Name = "lblTotalBudget";
            this.lblTotalBudget.Size = new System.Drawing.Size(35, 13);
            this.lblTotalBudget.TabIndex = 28;
            this.lblTotalBudget.Text = "label6";
            // 
            // lblAvailableAmount
            // 
            this.lblAvailableAmount.AutoSize = true;
            this.lblAvailableAmount.Location = new System.Drawing.Point(719, 125);
            this.lblAvailableAmount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAvailableAmount.Name = "lblAvailableAmount";
            this.lblAvailableAmount.Size = new System.Drawing.Size(35, 13);
            this.lblAvailableAmount.TabIndex = 29;
            this.lblAvailableAmount.Text = "label7";
            // 
            // lblExcessAmount
            // 
            this.lblExcessAmount.AutoSize = true;
            this.lblExcessAmount.Location = new System.Drawing.Point(719, 159);
            this.lblExcessAmount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExcessAmount.Name = "lblExcessAmount";
            this.lblExcessAmount.Size = new System.Drawing.Size(35, 13);
            this.lblExcessAmount.TabIndex = 30;
            this.lblExcessAmount.Text = "label8";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_Filter_Budget);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.txt_Filter_Budget_OC);
            this.groupBox3.Controls.Add(this.lbl_Filter_Budget_Date);
            this.groupBox3.Controls.Add(this.txt_Filter_Budget_Lease);
            this.groupBox3.Controls.Add(this.lbl_Filter_Budget_OperatingCosts);
            this.groupBox3.Controls.Add(this.lbl_Filter_Budget_Lease);
            this.groupBox3.Location = new System.Drawing.Point(39, 54);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(269, 150);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Budget by";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(163, 90);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 9;
            // 
            // txt_Filter_Budget_OC
            // 
            this.txt_Filter_Budget_OC.Location = new System.Drawing.Point(163, 55);
            this.txt_Filter_Budget_OC.Name = "txt_Filter_Budget_OC";
            this.txt_Filter_Budget_OC.Size = new System.Drawing.Size(100, 20);
            this.txt_Filter_Budget_OC.TabIndex = 8;
            // 
            // lbl_Filter_Budget_Date
            // 
            this.lbl_Filter_Budget_Date.AutoSize = true;
            this.lbl_Filter_Budget_Date.Location = new System.Drawing.Point(11, 95);
            this.lbl_Filter_Budget_Date.Name = "lbl_Filter_Budget_Date";
            this.lbl_Filter_Budget_Date.Size = new System.Drawing.Size(30, 13);
            this.lbl_Filter_Budget_Date.TabIndex = 6;
            this.lbl_Filter_Budget_Date.Text = "Date";
            // 
            // txt_Filter_Budget_Lease
            // 
            this.txt_Filter_Budget_Lease.Location = new System.Drawing.Point(163, 16);
            this.txt_Filter_Budget_Lease.Name = "txt_Filter_Budget_Lease";
            this.txt_Filter_Budget_Lease.Size = new System.Drawing.Size(100, 20);
            this.txt_Filter_Budget_Lease.TabIndex = 3;
            // 
            // lbl_Filter_Budget_OperatingCosts
            // 
            this.lbl_Filter_Budget_OperatingCosts.AutoSize = true;
            this.lbl_Filter_Budget_OperatingCosts.Location = new System.Drawing.Point(11, 57);
            this.lbl_Filter_Budget_OperatingCosts.Name = "lbl_Filter_Budget_OperatingCosts";
            this.lbl_Filter_Budget_OperatingCosts.Size = new System.Drawing.Size(81, 13);
            this.lbl_Filter_Budget_OperatingCosts.TabIndex = 1;
            this.lbl_Filter_Budget_OperatingCosts.Text = "Operating costs";
            // 
            // lbl_Filter_Budget_Lease
            // 
            this.lbl_Filter_Budget_Lease.AutoSize = true;
            this.lbl_Filter_Budget_Lease.Location = new System.Drawing.Point(11, 19);
            this.lbl_Filter_Budget_Lease.Name = "lbl_Filter_Budget_Lease";
            this.lbl_Filter_Budget_Lease.Size = new System.Drawing.Size(36, 13);
            this.lbl_Filter_Budget_Lease.TabIndex = 0;
            this.lbl_Filter_Budget_Lease.Text = "Lease";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(348, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Select Row to Update/Delete";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtProvince_Add);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.cbx_Lease_OC);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtAmount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(39, 388);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(269, 206);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add";
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(39, 173);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(145, 27);
            this.btnAdd.TabIndex = 43;
            this.btnAdd.Text = "Add";
            this.toolTip2.SetToolTip(this.btnAdd, "Adds New Budget for Province");
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // cbx_Lease_OC
            // 
            this.cbx_Lease_OC.FormattingEnabled = true;
            this.cbx_Lease_OC.Location = new System.Drawing.Point(91, 97);
            this.cbx_Lease_OC.Name = "cbx_Lease_OC";
            this.cbx_Lease_OC.Size = new System.Drawing.Size(121, 21);
            this.cbx_Lease_OC.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 41;
            this.label6.Text = "Component";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 40;
            this.label4.Text = "Province";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(91, 127);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(121, 20);
            this.txtAmount.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Amount";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDelete);
            this.groupBox2.Controls.Add(this.dateTimePicker2);
            this.groupBox2.Controls.Add(this.txtLease);
            this.groupBox2.Controls.Add(this.txtProvince);
            this.groupBox2.Controls.Add(this.btnUpdate);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(351, 388);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(357, 206);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Update";
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Location = new System.Drawing.Point(190, 173);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(145, 27);
            this.btnDelete.TabIndex = 46;
            this.btnDelete.Text = "Delete";
            this.toolTip4.SetToolTip(this.btnDelete, "Deletes Existing Budget");
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(93, 123);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(120, 20);
            this.dateTimePicker2.TabIndex = 10;
            // 
            // txtLease
            // 
            this.txtLease.Location = new System.Drawing.Point(92, 93);
            this.txtLease.Name = "txtLease";
            this.txtLease.Size = new System.Drawing.Size(121, 20);
            this.txtLease.TabIndex = 45;
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(93, 56);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.Size = new System.Drawing.Size(120, 20);
            this.txtProvince.TabIndex = 44;
            // 
            // btnUpdate
            // 
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(39, 173);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 27);
            this.btnUpdate.TabIndex = 43;
            this.btnUpdate.Text = "Update";
            this.toolTip3.SetToolTip(this.btnUpdate, "Updates Row of Data");
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 41;
            this.label8.Text = "Lease";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(37, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "Province";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(37, 123);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "Date";
            // 
            // btn_Filter_Budget
            // 
            this.btn_Filter_Budget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_Budget.Location = new System.Drawing.Point(118, 116);
            this.btn_Filter_Budget.Name = "btn_Filter_Budget";
            this.btn_Filter_Budget.Size = new System.Drawing.Size(145, 27);
            this.btn_Filter_Budget.TabIndex = 24;
            this.btn_Filter_Budget.Text = "Filter";
            this.toolTip1.SetToolTip(this.btn_Filter_Budget, "Displays Provincial Budget According to Inputs provided");
            this.btn_Filter_Budget.UseVisualStyleBackColor = true;
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Click";
            // 
            // toolTip2
            // 
            this.toolTip2.IsBalloon = true;
            this.toolTip2.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip2.ToolTipTitle = "Click";
            // 
            // toolTip3
            // 
            this.toolTip3.IsBalloon = true;
            this.toolTip3.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip3.ToolTipTitle = "Click";
            // 
            // txtProvince_Add
            // 
            this.txtProvince_Add.Location = new System.Drawing.Point(92, 65);
            this.txtProvince_Add.Name = "txtProvince_Add";
            this.txtProvince_Add.Size = new System.Drawing.Size(120, 20);
            this.txtProvince_Add.TabIndex = 45;
            // 
            // toolTip4
            // 
            this.toolTip4.IsBalloon = true;
            this.toolTip4.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip4.ToolTipTitle = "Click";
            // 
            // checkBox_BudgetApprove
            // 
            this.checkBox_BudgetApprove.AutoSize = true;
            this.checkBox_BudgetApprove.Location = new System.Drawing.Point(722, 204);
            this.checkBox_BudgetApprove.Name = "checkBox_BudgetApprove";
            this.checkBox_BudgetApprove.Size = new System.Drawing.Size(103, 17);
            this.checkBox_BudgetApprove.TabIndex = 45;
            this.checkBox_BudgetApprove.Text = "Approve Budget";
            this.checkBox_BudgetApprove.UseVisualStyleBackColor = true;
            // 
            // Budget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 595);
            this.Controls.Add(this.checkBox_BudgetApprove);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lblExcessAmount);
            this.Controls.Add(this.lblAvailableAmount);
            this.Controls.Add(this.lblTotalBudget);
            this.Controls.Add(this.dgvBudget);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Name = "Budget";
            this.Text = "Budget";
            this.Load += new System.EventHandler(this.Budget_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBudget)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvBudget;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotalBudget;
        private System.Windows.Forms.Label lblAvailableAmount;
        private System.Windows.Forms.Label lblExcessAmount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_Filter_Budget_Date;
        private System.Windows.Forms.TextBox txt_Filter_Budget_Lease;
        private System.Windows.Forms.Label lbl_Filter_Budget_OperatingCosts;
        private System.Windows.Forms.Label lbl_Filter_Budget_Lease;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_Filter_Budget_OC;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_Lease_OC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox txtLease;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_Filter_Budget;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.TextBox txtProvince_Add;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.CheckBox checkBox_BudgetApprove;
    }
}