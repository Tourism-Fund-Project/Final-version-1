﻿
namespace Tourism_Fund_Distribution_final.Forms
{
    partial class Tourist_Attractions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxRegion = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbx_Filter_TACategory = new System.Windows.Forms.ComboBox();
            this.txt_Filter_TADescription = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Filter_TAName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtRevenue = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbx_TACategory = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txt_TADescription = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_TAName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewTouristAttraction = new System.Windows.Forms.DataGridView();
            this.btn_Filter_TA = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTouristAttraction)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxRegion
            // 
            this.cbxRegion.FormattingEnabled = true;
            this.cbxRegion.Location = new System.Drawing.Point(366, 25);
            this.cbxRegion.Name = "cbxRegion";
            this.cbxRegion.Size = new System.Drawing.Size(121, 21);
            this.cbxRegion.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(407, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Province";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(363, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Select Row to Update/Delete";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_Filter_TA);
            this.groupBox3.Controls.Add(this.cbx_Filter_TACategory);
            this.groupBox3.Controls.Add(this.txt_Filter_TADescription);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txt_Filter_TAName);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(21, 58);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(279, 160);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Filter Tourist Attractions by";
            // 
            // cbx_Filter_TACategory
            // 
            this.cbx_Filter_TACategory.FormattingEnabled = true;
            this.cbx_Filter_TACategory.Location = new System.Drawing.Point(158, 66);
            this.cbx_Filter_TACategory.Name = "cbx_Filter_TACategory";
            this.cbx_Filter_TACategory.Size = new System.Drawing.Size(100, 21);
            this.cbx_Filter_TACategory.TabIndex = 32;
            // 
            // txt_Filter_TADescription
            // 
            this.txt_Filter_TADescription.Location = new System.Drawing.Point(158, 101);
            this.txt_Filter_TADescription.Name = "txt_Filter_TADescription";
            this.txt_Filter_TADescription.Size = new System.Drawing.Size(100, 20);
            this.txt_Filter_TADescription.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Description";
            // 
            // txt_Filter_TAName
            // 
            this.txt_Filter_TAName.Location = new System.Drawing.Point(158, 25);
            this.txt_Filter_TAName.Name = "txt_Filter_TAName";
            this.txt_Filter_TAName.Size = new System.Drawing.Size(100, 20);
            this.txt_Filter_TAName.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Category";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtRevenue);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbx_TACategory);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnUpdate);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.txt_TADescription);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_TAName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(21, 426);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(490, 163);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Region info";
            // 
            // txtRevenue
            // 
            this.txtRevenue.Location = new System.Drawing.Point(356, 86);
            this.txtRevenue.Name = "txtRevenue";
            this.txtRevenue.Size = new System.Drawing.Size(100, 20);
            this.txtRevenue.TabIndex = 36;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(280, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 13);
            this.label9.TabIndex = 35;
            this.label9.Text = "Revenue";
            // 
            // cbx_TACategory
            // 
            this.cbx_TACategory.FormattingEnabled = true;
            this.cbx_TACategory.Location = new System.Drawing.Point(356, 38);
            this.cbx_TACategory.Name = "cbx_TACategory";
            this.cbx_TACategory.Size = new System.Drawing.Size(100, 21);
            this.cbx_TACategory.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(284, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "Category";
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Location = new System.Drawing.Point(339, 130);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(145, 27);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(177, 130);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 27);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(17, 130);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(145, 27);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // txt_TADescription
            // 
            this.txt_TADescription.Location = new System.Drawing.Point(82, 89);
            this.txt_TADescription.Name = "txt_TADescription";
            this.txt_TADescription.Size = new System.Drawing.Size(100, 20);
            this.txt_TADescription.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description";
            // 
            // txt_TAName
            // 
            this.txt_TAName.Location = new System.Drawing.Point(82, 43);
            this.txt_TAName.Name = "txt_TAName";
            this.txt_TAName.Size = new System.Drawing.Size(100, 20);
            this.txt_TAName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // dataGridViewTouristAttraction
            // 
            this.dataGridViewTouristAttraction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTouristAttraction.Location = new System.Drawing.Point(21, 224);
            this.dataGridViewTouristAttraction.Name = "dataGridViewTouristAttraction";
            this.dataGridViewTouristAttraction.RowHeadersWidth = 62;
            this.dataGridViewTouristAttraction.Size = new System.Drawing.Size(490, 171);
            this.dataGridViewTouristAttraction.TabIndex = 28;
            // 
            // btn_Filter_TA
            // 
            this.btn_Filter_TA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Filter_TA.Location = new System.Drawing.Point(113, 127);
            this.btn_Filter_TA.Name = "btn_Filter_TA";
            this.btn_Filter_TA.Size = new System.Drawing.Size(145, 27);
            this.btn_Filter_TA.TabIndex = 33;
            this.btn_Filter_TA.Text = "Filter";
            this.btn_Filter_TA.UseVisualStyleBackColor = true;
            // 
            // Tourist_Attractions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 595);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewTouristAttraction);
            this.Controls.Add(this.cbxRegion);
            this.Controls.Add(this.label1);
            this.Name = "Tourist_Attractions";
            this.Text = "Tourist_Attractions";
            this.Load += new System.EventHandler(this.Tourist_Attractions_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTouristAttraction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cbxRegion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_Filter_TADescription;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Filter_TAName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txt_TADescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_TAName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridViewTouristAttraction;
        private System.Windows.Forms.ComboBox cbx_Filter_TACategory;
        private System.Windows.Forms.TextBox txtRevenue;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbx_TACategory;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_Filter_TA;
    }
}