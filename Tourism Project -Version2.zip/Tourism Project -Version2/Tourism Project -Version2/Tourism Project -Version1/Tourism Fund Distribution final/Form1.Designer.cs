﻿
namespace Tourism_Fund_Distribution_final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnAF = new System.Windows.Forms.Button();
            this.btnBudget = new System.Windows.Forms.Button();
            this.btnReviews = new System.Windows.Forms.Button();
            this.btnNeeds = new System.Windows.Forms.Button();
            this.btnTA = new System.Windows.Forms.Button();
            this.btnRegionMenu = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.lblUser = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTitleBar.SuspendLayout();
            this.panelDesktop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(77)))));
            this.panelMenu.Controls.Add(this.btnReport);
            this.panelMenu.Controls.Add(this.btnAF);
            this.panelMenu.Controls.Add(this.btnBudget);
            this.panelMenu.Controls.Add(this.btnReviews);
            this.panelMenu.Controls.Add(this.btnNeeds);
            this.panelMenu.Controls.Add(this.btnTA);
            this.panelMenu.Controls.Add(this.btnRegionMenu);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 35);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(220, 634);
            this.panelMenu.TabIndex = 0;
            // 
            // btnReport
            // 
            this.btnReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnReport.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.chart_line_line;
            this.btnReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.Location = new System.Drawing.Point(0, 362);
            this.btnReport.Name = "btnReport";
            this.btnReport.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnReport.Size = new System.Drawing.Size(220, 47);
            this.btnReport.TabIndex = 7;
            this.btnReport.Text = "         Report";
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnAF
            // 
            this.btnAF.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAF.FlatAppearance.BorderSize = 0;
            this.btnAF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAF.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAF.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnAF.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.wallet_fill;
            this.btnAF.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAF.Location = new System.Drawing.Point(0, 315);
            this.btnAF.Name = "btnAF";
            this.btnAF.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAF.Size = new System.Drawing.Size(220, 47);
            this.btnAF.TabIndex = 6;
            this.btnAF.Text = "         Access funds";
            this.btnAF.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAF.UseVisualStyleBackColor = true;
            this.btnAF.Click += new System.EventHandler(this.btnAF_Click);
            // 
            // btnBudget
            // 
            this.btnBudget.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBudget.FlatAppearance.BorderSize = 0;
            this.btnBudget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBudget.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBudget.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnBudget.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.pig_money_line;
            this.btnBudget.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBudget.Location = new System.Drawing.Point(0, 268);
            this.btnBudget.Name = "btnBudget";
            this.btnBudget.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnBudget.Size = new System.Drawing.Size(220, 47);
            this.btnBudget.TabIndex = 5;
            this.btnBudget.Text = "         Budget";
            this.btnBudget.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBudget.UseVisualStyleBackColor = true;
            this.btnBudget.Click += new System.EventHandler(this.btnBudget_Click);
            // 
            // btnReviews
            // 
            this.btnReviews.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnReviews.FlatAppearance.BorderSize = 0;
            this.btnReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReviews.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReviews.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnReviews.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.star_half_fill;
            this.btnReviews.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReviews.Location = new System.Drawing.Point(0, 221);
            this.btnReviews.Name = "btnReviews";
            this.btnReviews.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnReviews.Size = new System.Drawing.Size(220, 47);
            this.btnReviews.TabIndex = 4;
            this.btnReviews.Text = "         Reviews";
            this.btnReviews.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReviews.UseVisualStyleBackColor = true;
            this.btnReviews.Click += new System.EventHandler(this.btnReviews_Click);
            // 
            // btnNeeds
            // 
            this.btnNeeds.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNeeds.FlatAppearance.BorderSize = 0;
            this.btnNeeds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNeeds.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNeeds.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnNeeds.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.tool_line;
            this.btnNeeds.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNeeds.Location = new System.Drawing.Point(0, 174);
            this.btnNeeds.Name = "btnNeeds";
            this.btnNeeds.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnNeeds.Size = new System.Drawing.Size(220, 47);
            this.btnNeeds.TabIndex = 3;
            this.btnNeeds.Text = "         Needs";
            this.btnNeeds.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNeeds.UseVisualStyleBackColor = true;
            this.btnNeeds.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTA
            // 
            this.btnTA.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTA.FlatAppearance.BorderSize = 0;
            this.btnTA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTA.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTA.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.temple_of_heaven_line;
            this.btnTA.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTA.Location = new System.Drawing.Point(0, 127);
            this.btnTA.Name = "btnTA";
            this.btnTA.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnTA.Size = new System.Drawing.Size(220, 47);
            this.btnTA.TabIndex = 2;
            this.btnTA.Text = "         Tourist Attractions";
            this.btnTA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTA.UseVisualStyleBackColor = true;
            this.btnTA.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRegionMenu
            // 
            this.btnRegionMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRegionMenu.FlatAppearance.BorderSize = 0;
            this.btnRegionMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegionMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegionMenu.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnRegionMenu.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.location_2_line__1_;
            this.btnRegionMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegionMenu.Location = new System.Drawing.Point(0, 80);
            this.btnRegionMenu.Name = "btnRegionMenu";
            this.btnRegionMenu.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnRegionMenu.Size = new System.Drawing.Size(220, 47);
            this.btnRegionMenu.TabIndex = 1;
            this.btnRegionMenu.Text = "          Region";
            this.btnRegionMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRegionMenu.UseVisualStyleBackColor = true;
            this.btnRegionMenu.Click += new System.EventHandler(this.btnRegionMenu_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.panelLogo.Controls.Add(this.lblUser);
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(220, 80);
            this.panelLogo.TabIndex = 0;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblUser.Location = new System.Drawing.Point(83, 22);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(38, 17);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "User";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tourism_Fund_Distribution_final.Properties.Resources.user_1_line__2_;
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 62);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.Green;
            this.panelTitleBar.Controls.Add(this.button1);
            this.panelTitleBar.Controls.Add(this.lblTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(0, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(1149, 35);
            this.panelTitleBar.TabIndex = 1;
            this.panelTitleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouse_Down);
            this.panelTitleBar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouse_Move);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(1111, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(620, 7);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(72, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HOME";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);
            // 
            // panelDesktop
            // 
            this.panelDesktop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelDesktop.Controls.Add(this.pictureBox2);
            this.panelDesktop.Controls.Add(this.label1);
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktop.Location = new System.Drawing.Point(220, 35);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(929, 634);
            this.panelDesktop.TabIndex = 2;
            this.panelDesktop.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDesktop_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(15, 41);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(902, 581);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(242, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(468, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome to the Toursim Fund Distribution Sytem";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "00-the-top15-best-tourist-attractions-in-southafrica-BW-1200px.jpg");
            this.imageList1.Images.SetKeyName(1, "032890633d5e64ac7c10fbb71fd01688.jpg");
            this.imageList1.Images.SetKeyName(2, "Anton-Kruger-madikwe.jpg");
            this.imageList1.Images.SetKeyName(3, "drakensberg-2060411_960_720.jpg");
            this.imageList1.Images.SetKeyName(4, "Kimberley-Big-Hole.jpeg");
            this.imageList1.Images.SetKeyName(5, "muizenberg-2305734_960_720.jpg");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 669);
            this.Controls.Add(this.panelDesktop);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelTitleBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(1149, 669);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            this.panelDesktop.ResumeLayout(false);
            this.panelDesktop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnRegionMenu;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnAF;
        private System.Windows.Forms.Button btnBudget;
        private System.Windows.Forms.Button btnReviews;
        private System.Windows.Forms.Button btnNeeds;
        private System.Windows.Forms.Button btnTA;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelDesktop;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
    }
}

