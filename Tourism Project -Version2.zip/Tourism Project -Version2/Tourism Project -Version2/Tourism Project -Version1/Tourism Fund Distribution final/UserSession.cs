﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tourism_Fund_Distribution_final
{
    public static class UserSession
    {
        public static string UserRole { get; set; }
        public static string UserName { get; set; }
    }
}
